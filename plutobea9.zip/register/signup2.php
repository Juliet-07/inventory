<?php  

require "connection.php";



// If form submitted, insert values into the database.
if (isset($_REQUEST['username'])){
  
//   $fullname = stripslashes($_REQUEST['fullname']);
//   $fullname = mysqli_real_escape_string($conn,$fullname);

// $email = stripslashes($_REQUEST['email']);
// $email = mysqli_real_escape_string($conn,$email);
// $mobile = stripslashes($_REQUEST['mobile']);
// $mobile = mysqli_real_escape_string($conn,$mobile);
// $username = stripslashes($_REQUEST['username']);
// $username = mysqli_real_escape_string($conn,$username); 
// $password = stripslashes($_REQUEST['password']);
// $password = mysqli_real_escape_string($conn,$password);
// $query = "INSERT into `users` (fullname, email, mobile, username,  password)
// VALUES ('$fullname',  '$email', '$mobile', '$username', '$password')";
//   $result = mysqli_query($conn,$query);
//   if($result){
//       echo "<script type='text/javascript'> document.location = 'login.php'; </script>";
//   }
// }else{

?>




<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />
    <title>INVENTORY CONTROL SYSTEM</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
    <!-- Bootstrap Icons-->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css"
      rel="stylesheet"
    />
    <!-- Google fonts-->
    <link
      href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700"
      rel="stylesheet"
    />
    <link
      href="https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic"
      rel="stylesheet"
      type="text/css"
    />
    <!-- SimpleLightbox plugin CSS-->
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/SimpleLightbox/2.1.0/simpleLightbox.min.css"
      rel="stylesheet"
    />
    <!-- Core theme CSS (includes Bootstrap)-->
    <!-- <link rel="stylesheet" href="styles.css"> -->
    <link rel="stylesheet" href="../styling.css" />
    <link rel="stylesheet" href="signup.css" />
  </head>
  <body id="page-top">
    <!-- HEADER (REGISTRATION)-->
    <header class="masthead">
      <div class="container px-4 px-lg-5 h-100">
        <div
          class="row gx-4 gx-lg-5 h-100 align-items-center justify-content-center text-center"
        >
          <h2 class="text-white">SIGN-UP TO BE ELIGIBLE TO USE THIS SITE</h2>
          <p class="text-white">Please enter your credentials to proceed</p>

          <div class="signup-form">
            <form action="" method="post" class="form-horizontal" >
                  <div class="row">
                    <div class="col-8 offset-4">
                        <h2>Sign Up</h2>
                    </div>	
                  </div>
                  <div class="form-group row">
                    <label class="col-form-label col-4">Full Name</label>
                    <div class="col-8">
                        <input type="text" class="form-control" name="fullname" required="required">
                    </div>        	
                </div>
                <div class="form-group row">
                    <label class="col-form-label col-4">Email</label>
                    <div class="col-8">
                        <input type="email" class="form-control" name="email" required="required">
                    </div>        	
                </div>
                <div class="form-group row">
                  <label class="col-form-label col-4">Phone Number</label>
                  <div class="col-8">
                      <input type="number" class="form-control" name="mobile" required="required">
                  </div>        	
              </div>
                <div class="form-group row">
                    <label class="col-form-label col-4">Username</label>
                    <div class="col-8">
                        <input type="text" class="form-control" name="username" required="required">
                    </div>        	
                </div>
                <div class="form-group row">
                    <label class="col-form-label col-4">Password</label>
                    <div class="col-8">
                        <input type="password" class="form-control" name="password" required="required">
                    </div>        	
                </div>
                <div class="form-group row">
                    <label class="col-form-label col-4">Confirm Password</label>
                    <div class="col-8">
                        <input type="password" class="form-control" name="confirm_password" required="required" >
                    </div>        	
                </div>
                <div class="form-group row">
                    <div class="col-8 offset-4">
                        <p><label class="form-check-label"><input type="checkbox" required="required"> I accept the <a href="#">Terms of Use</a> &amp; <a href="#">Privacy Policy</a>.</label></p>
                    </div>
                    <button type="submit" name="submit" class="btn btn-primary btn-lg">Sign Up</button>
                </div>		      
            </form>
            <div class="text-center">Already have an account? <a href="./login.php">Login here</a></div>
        </div>
    </header>
    <script src="../script.js"></script>
  </body>
</html>
<?php } ?>