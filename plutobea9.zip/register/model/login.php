<?php
include '../function.php';
    $username = tres($_POST['username']);
    $password = tres($_POST['password']);
    
    $result = $con->query("SELECT * FROM users WHERE username = '$username' AND password = '$password'");
    if($result->num_rows!=0){
        $row = $result->fetch_assoc();
		$_SESSION['username'] = $username;
		$_SESSION['id'] = $row['id'];
		header("Location: https://plutobeautycafe.com/recoder/index.php");
    }else{
        header("Location: ../login.php");
    }
?>