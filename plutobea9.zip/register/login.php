<?php

require "connection.php";

session_start();
// If form submitted, insert values into the database.
if (isset($_POST['username'])){
        // removes backslashes
	$username = stripslashes($_REQUEST['username']);
        //escapes special characters in a string
	$username = mysqli_real_escape_string($conn,$username);
	$password = stripslashes($_REQUEST['password']);
	$password = mysqli_real_escape_string($conn,$password);
	//Checking is user existing in the database or not
        $query = "SELECT * FROM `users` WHERE username='$username'
and password='$password'";
	$result = mysqli_query($conn,$query) or die(mysqli_connect_error());
	$rows = mysqli_num_rows($result);
  
        if($rows==1){
	    $_SESSION['username'] = $username;
            // Redirect user to index.php
	    header("Location: ../recoder/index.php");
         }else{
	echo "<script>alert('Incorrect username and password')
  window.location='login.php'
</script>";  
 	}
    }else{
   
?>




<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />
    <title>INVENTORY CONTROL SYSTEM</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
    <!-- Bootstrap Icons-->

    <link rel="stylesheet" href="../recoder/index.php">
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css"
      rel="stylesheet"
    />
    <!-- Google fonts-->
    <link
      href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700"
      rel="stylesheet"
    />
    <link
      href="https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic"
      rel="stylesheet"
      type="text/css"
    />
    <!-- SimpleLightbox plugin CSS-->
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/SimpleLightbox/2.1.0/simpleLightbox.min.css"
      rel="stylesheet"
    />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link rel="stylesheet" href="../styling.css"/>
    <link rel="stylesheet" href="signup.css"/>
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="./style.css">
  </head>
  <body>
    <div class="main">
        <div
          class=" row gx-4 gx-lg-5 px-4 px-lg-5 h-100 align-items-center justify-content-center text-center"
        >
          <div class="sub-main-w3">
            <h1 class="text-white">WELCOME</h1>
            <form class="login" action="" method="post">
                <p class="legend">Login Here</p>
               
                <div class="input">
                  <input type="text" name="username" placeholder="Username" required />
                  <span class="fa fa-user"></span>
                </div>
                <div class="input">
                  <input type="password" placeholder="Password" name="password" required />
                  <span class="fa fa-unlock"></span>
                </div>
                <div class="form-group row">
                  <button type="submit" class="btn btn-primary">Login </button>
                  <!-- <a href="../recoder/index.html">Login</a> -->
                </div>
              </div>		      
              <!-- <div class="box text-center">Don't have an account? <a href="./signup.html">Sign-up here</a>
              </div> -->
            </form>
        </div>
    <script src="../script.js"></script>
  </body>
</html>
<?php } ?>