<?php
    $con = mysqli_connect("localhost","elite_delivery","implication","FlashPointxpress");
    if(mysqli_connect_errno()){
        echo "Failed to connect to MySQL: " . mysqli_connect_error().' '.  mysqli_connect_errno();
    }
    $route_url = 'https://headlines09.com';
    $mail_email = "";
    $mail_password ="";
    $mail_name = "headlines09";
?>