<?php
    include '../../function.php';
    $name = tres($_POST['name']);
    $phone = tres($_POST['phone']);
    
    $con->query("UPDATE admin SET name = '$name', phone = '$phone' WHERE id = '".$_SESSION['reporter_id']."'");
    header("Location: ../8");
?>