<?php
    include '../function.php';
    $email = tres($_POST['email']);
    $password = tres($_POST['password']);
    
    $result = $con->query("SELECT * FROM admin WHERE email = '$email' AND password = '$password'");
    if($result->num_rows!=0){
        $row = $result->fetch_assoc();
		$_SESSION['admin_email'] = $email;
		$_SESSION['admin_id'] = $row['id'];
		header("Location: ../index.php");
    }else{
        header("Location: ../login.php");
    }
?>