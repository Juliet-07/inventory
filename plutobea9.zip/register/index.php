<?php
    header("Location: signup.php");
    exit;