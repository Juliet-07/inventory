<?php
    session_start();
    include 'connection.php';
    mysqli_set_charset($con,"utf8");
    function get_date(){
        $timezone = "Asia/Kolkata";
        if (function_exists('date_default_timezone_set'))
        date_default_timezone_set($timezone);
        return $date = date('Y-m-d');
    }
    function get_time(){
        $timezone = "Asia/Kolkata";
        if (function_exists('date_default_timezone_set'))
        date_default_timezone_set($timezone);
        return $outfile = date('H:i:s');
    }
    function formatdate($date){
        $date = date('d-m-Y', strtotime($date));
        return $date;
    }
    
    function formatdate2($date){
        $date = date('d F, Y', strtotime($date));
        return $date;
    }
    function formatdate3($date){
        $date = date('d-m-Y h:i A', strtotime($date));
        return $date;
    }
	
    function setMessage($message, $type){
        $_SESSION['SetMessage']='<div class="'.$type.'">'.$message.'</div>';
    }

    function getMessage(){
        $GetMessage = @$_SESSION['SetMessage'];
        unset($_SESSION['SetMessage']);
        return $GetMessage; 
    }
    
    function tres($text){ 
        global $con;
        return trim(mysqli_real_escape_string($con, $text));
    }
    
    function redirect($location){
        echo '<script>window.location.href="'.$location.'";</script>';
    }
    function redirect2($location){
        header("Location: $location");
    }
    function get_unique_token($length, $table, $column){
        $result = getToken($length);
        global $con;
        $result_ck = $con->query("SELECT id FROM $table WHERE $column = '$result'");
        if($result_ck->num_rows!=0){
            $result = get_unique_token($length);
        }else{
            return $result;
        }
    } 

    function crypto_rand_secure($min, $max) {
        $range = $max - $min;
        if ($range < 0) return $min; 
        $log = log($range, 2);
        $bytes = (int) ($log / 8) + 1; 
        $bits = (int) $log + 1; 
        $filter = (int) (1 << $bits) - 1; 
        do {
            $rnd = hexdec(bin2hex(openssl_random_pseudo_bytes($bytes)));
            $rnd = $rnd & $filter; 
        } while ($rnd >= $range);
        return $min + $rnd;
    }
    function getToken($length){
        $token = "";
        $codeAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $codeAlphabet.= "abcdefghijklmnopqrstuvwxyz";
        $codeAlphabet.= "0123456789";
        for($i=0;$i<$length;$i++){
            $token .= $codeAlphabet[crypto_rand_secure(0,strlen($codeAlphabet))];
        }
        return $token;
    }
    
    function generateId() {
        $id= rand(1, 9);
        for($i = 1; $i<=4;$i++){
            $id= $id.rand(0, 9);
        }
        return $id;
    }
    function createCustomerId() {
        global $con;
        $id = 'RC'.generateId();
        $result = $con->query("SELECT id FROM customer WHERE customer_id = '".$id."'");
        if($result->num_rows!=0) {
            createCustomerId();
        }
        else {
            return $id;    
        }
    }
    
    
    
    function get_latlng($address) {
        $address = urlencode(trim($address));
        $details_url = "https://maps.googleapis.com/maps/api/geocode/json?address=" . $address . "&sensor=false";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $details_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $response = json_decode(curl_exec($ch), true);
        if ($response['status'] != 'OK') {
            return null;
        }
        $latLng = $response['results'][0]['geometry']['location'];
        return $latLng;
    }
    
    function distance($lat1, $lon1, $lat2, $lon2, $unit){
        $theta = $lon1 - $lon2;
        $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
        $dist = acos($dist);
        $dist = rad2deg($dist);
        $miles = $dist * 60 * 1.1515;
        $unit = strtoupper($unit);
        if ($unit == "K") {
          return ($miles * 1.609344);
        } else if ($unit == "N") {
            return ($miles * 0.8684);
        }else{
            return $miles;
        }
    }
    
    
    function select_global($table,  $select_column, $match_column, $match_value){
        global $con;
        $result = $con->query("SELECT $select_column FROM `$table` WHERE $match_column = '".$match_value."'");
        if($result->num_rows==0){
            return 'null';
        }
        if($select_column =="*"){
            $row = $result->fetch_object()->$select_column;
            return $row;
        }else{
            $retrun = $result->fetch_object()->$select_column;
            return $retrun;
        }
        
    }
    
    
    function get_email_body($text){
        $body = '<div style="background: #dfdfdf;padding: 20px 80px 40px 80px;">
                <span><img src="https://bounced.co.uk/images/logo/logo.png" style="width: 200px;"></span>
                <div style="background: #a71519;min-height: 20px;"></div>
                <div style="background: white;font-family: arial,sans-serif;padding: 30px;">
                    '.$text.'
                    <p>Thanks for using Bounced!</p>
                    <p>The Bounced Team</p>
                </div>
                <div style="background: #f1f1f1;min-height: 50px;margin-top: 10px;"></div>
                <div style="text-align: center;">
                    <p style="font-size: 12px;font-family: arial,sans-serif;color:#888686;">� 2016 Bounced a dating website for any other query please <a style="color:#768ad8;" href="">contact</a> with us.</p>
                </div>
            </div>';
        return $body;
    }
    function getAddressLatLng($lat,$lng){
//        $geocode=file_get_contents("https://maps.googleapis.com/maps/api/geocode/json?latlng=$lat,$lng&sensor=false");
//        $output= json_decode($geocode);
//        return $output->results[0]->formatted_address;
        $url = "https://maps.googleapis.com/maps/api/geocode/json?latlng=$lat,$lng&sensor=false";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_PROXYPORT, 3128);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        $response = curl_exec($ch);
        curl_close($ch);
        $response_a = json_decode($response);
        return $response_a->results[0]->formatted_address;
    }
    function get_string($str, $maxlen){
        if (strlen($str) <= $maxlen){
            return $str;
        }else{
            $newstr = substr($str, 0, $maxlen);
            if (substr($newstr, -1, 1) != ' '){
                $newstr = substr($newstr, 0, strrpos($newstr, " "));
            }
            return $newstr.'...';
        }
    }
    function get_country_list(){
        global $con;
        $country = array();
        $result = $con->query("SELECT short_name FROM country");
        while($row = $result->fetch_object()){
            $country[] = $row->short_name;
        }
        return $country;
    }
    
    
    
    function unique_name($title) {
        $char = array(",", "/", "\/", "?", ":", "‘", "’");
        $post_name = trim($title);
        $post_name = str_replace(" ", "-", $post_name);
        $post_name = str_replace($char, "", $post_name);
        $post_name = get_string($post_name, 200);
//        $post_name = str_replace("/", "", $post_name);
//        $post_name = str_replace("\/", "", $post_name);
//        $post_name = str_replace("?", "", $post_name);
        return $post_name;
    }
   
	
	function insertData($table, $data){
        global $con;
         $string_field = "";
         $string_value = "";
        foreach ($data AS $key=>$value){
            if($string_field ==''){
                $string_field.= "`$key`";
            }else{
                $string_field.= ", `$key`";
            }
            
            if($string_value ==''){
                $string_value.= "'".tres($value)."'";
            }else{
                $string_value.= ", '".tres($value)."'";
            }
        }
        $con->query("INSERT INTO $table($string_field)VALUES($string_value)");
        $last_insert_id = mysqli_insert_id($con);
        return $last_insert_id;
    }
	function digit2($number){
        return number_format($number, 2, '.', '');
    }
?>