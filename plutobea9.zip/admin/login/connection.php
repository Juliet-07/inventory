<?php
    $con = mysqli_connect("localhost","root","","plutobea_pluto");
    if(mysqli_connect_errno()){
        echo "Failed to connect to MySQL: " . mysqli_connect_error().' '.  mysqli_connect_errno();
    }
    $route_url = 'https://headlines09.com';
    $mail_email = "";
    $mail_password ="";
    $mail_name = "headlines09";
?>


<!-- $con = mysqli_connect("localhost","plutobea_pluto","Sanfermin96@","plutobea_pluto");
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }

mysqli_select_db("ob");



$con = new mysqli("localhost","plutobea_pluto","Sanfermin96@","plutobea_pluto");
if ($con->connect_errno) {
    echo "Failed to connect to mysqli: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
} -->
