<?php
	include '../function.php';
	$docket_number = tres($_GET['docket_number']);
	$con->query("DELETE FROM consignment WHERE docket_number = '$docket_number'");
	header("Location: ../consignment.php");
?>