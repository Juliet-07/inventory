<?php
	include '../function.php';
	$csid  = tres($_GET['csid']);
	$docket_number = tres($_GET['docket_number']);
	$con->query("DELETE FROM consignment_status WHERE csid = '$csid'");
	header("Location: ../consignment-edit.php?docket_number=$docket_number");
?>