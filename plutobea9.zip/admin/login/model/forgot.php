<?php
	include '../function.php';
	include '../../email/mail-lib.php';
	
	$email= tres($_POST['email']);
	$result = $con->query("SELECT * FROM admin WHERE email = '$email'");
	if($result->num_rows!=0){
		$password = $result->fetch_object()->password;
		
		$subject = 'Admin forgot password notification';
		$body = "<div>Below is your newgati admin password</div>";
		$body.= "<div>Password: <b>$password</b></div>";
		email($email, $subject, $body);
	}
	header("Location: ../login.php");
?>