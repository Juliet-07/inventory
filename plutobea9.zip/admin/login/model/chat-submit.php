<?php
	include '../function.php';
	$chat_id = tres($_POST['chat_id']);
	$message = tres($_POST['message']);
	$datetime = get_date().' '.get_time();
	
	$con->query("INSERT INTO chat_history(chat_id, sender, message, datetime)VALUES('$chat_id', 'admin', '$message', '$datetime')");
	header("Location: ../chat-history.php?chat_id=$chat_id");
?>