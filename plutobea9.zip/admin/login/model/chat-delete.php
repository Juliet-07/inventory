<?php
	include '../function.php';
	$chat_id = tres($_GET['chat_id']);
	$con->query("DELETE FROM chat WHERE chat_id ='$chat_id'");
	$con->query("DELETE FROM chat_history WHERE chat_id ='$chat_id'");
	header("Location: ../chat.php");
?>