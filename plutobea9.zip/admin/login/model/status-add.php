<?php
	include '../function.php';
	$docket_number = tres($_POST['docket_number']);
	$location = tres($_POST['location']);
	$status = tres($_POST['status']);
	$date = get_date();
	$time = get_time();
	$con->query("INSERT INTO consignment_status(docket_number, location, status, date, time)VALUES('$docket_number', '$location', '$status', '$date', '$time')");
	header("Location: ../consignment-edit.php?docket_number=$docket_number");
?>