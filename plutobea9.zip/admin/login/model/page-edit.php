<?php
    include '../function.php';
	$city = strtolower(tres($_POST['city']));
	$city_u = str_replace(' ', '-', $city);
	$page_url = 'packers-and-movers-'.$city_u.'.html';
	$state_city = tres($_POST['state_city']);
	$page_id = tres($_POST['page_id']);
    $city = tres($_POST['city']);
	$heading = tres($_POST['heading']);
    $description = tres($_POST['description']);
	
	
	$meta_title = tres($_POST['meta_title']);
	$meta_keyword = tres($_POST['meta_keyword']);
	$meta_description = tres($_POST['meta_description']);
	$meta_subject = tres($_POST['meta_subject']);
	$geo_region = tres($_POST['geo_region']);
	$geo_place = tres($_POST['geo_place']);
	$geo_position = tres($_POST['geo_position']);
	$icbm = tres($_POST['icbm']);	
	$postal_code = tres($_POST['postal_code']);
	$street_address = tres($_POST['street_address']);
	$street_address2 = tres($_POST['street_address2']);
	$status = tres($_POST['status']);
    
	$email = tres($_POST['email']);
	$phone_number = tres($_POST['phone_number']);
	$map_src = tres($_POST['map_src']);
    $con->query("UPDATE page SET heading = '$heading', city = '$city', description='$description', meta_title = '$meta_title', meta_keyword = '$meta_keyword', meta_description = '$meta_description', geo_region = '$geo_region', geo_place ='$geo_place', geo_position = '$geo_position', icbm ='$icbm', status ='$status', page_url = '$page_url', postal_code = '$postal_code', street_address = '$street_address', street_address2 = '$street_address2' ,state_city = '$state_city', phone_number = '$phone_number', email = '$email', map_src = '$map_src' WHERE page_id = '$page_id'");
  
    setMessage("Page Updated successfully", 'alert-success');
    header("Location: ../page-edit.php?page_id=$page_id");
?>