<?php
	include '../function.php';
	$datetime = get_date().' '.get_time();
	
	$consignment_number = tres($_POST['consignment_number']);
	$amount = tres($_POST['amount']);
	$billing_name = tres($_POST['billing_name']);
	$billing_address = tres($_POST['billing_address']);
	$billing_city = tres($_POST['billing_city']);
	$billing_state = tres($_POST['billing_state']);
	$billing_zip = tres($_POST['billing_zip']);
	$billing_country = tres($_POST['billing_country']);
	$billing_tel = tres($_POST['billing_tel']);
	$billing_email = tres($_POST['billing_email']);
	
	$billing_zip = tres($_POST['billing_zip']);
	$billing_zip = tres($_POST['billing_zip']);
	$billing_zip = tres($_POST['billing_zip']);
	$billing_zip = tres($_POST['billing_zip']);
	$billing_zip = tres($_POST['billing_zip']);
	
	$delivery_name = tres($_POST['delivery_name']);
	$delivery_address = tres($_POST['delivery_address']);
	$delivery_city = tres($_POST['delivery_city']);
	$delivery_state = tres($_POST['delivery_state']);
	$delivery_zip = tres($_POST['delivery_zip']);
	$delivery_country = tres($_POST['delivery_country']);
	$delivery_tel = tres($_POST['delivery_tel']);
	
	$con->query("INSERT INTO `order`(consignment_number, amount, datetime, billing_name, billing_address, billing_city, billing_state, billing_zip, delivery_name, delivery_address, delivery_city, delivery_state, delivery_zip, delivery_country, delivery_tel)VALUES('$consignment_number','$amount', '$datetime', '$billing_name', '$billing_address', '$billing_city', '$billing_state', '$billing_zip', '$delivery_name', '$delivery_address', '$delivery_city', '$delivery_state', '$delivery_zip', '$delivery_country', '$delivery_tel')");
	
	header("Location: ../order.php"); 
?>