<?php
	include '../function.php';
	$consignment_number = tres($_POST['consignment_number']);
	$vehicle_type = tres($_POST['vehicle_type']);
	$origin = tres($_POST['origin']);
	$destination = tres($_POST['destination']);
	$pickup_date = tres($_POST['pickup_date']);
	$no_of_package = tres($_POST['no_of_package']);
	$assured_dly_dt = tres($_POST['assured_dly_dt']);
	$delivery_dt = tres($_POST['delivery_dt']);
	$receiver_name = tres($_POST['receiver_name']);
	
	$con->query("INSERT INTO consignment(vehicle_type, consignment_number, origin, destination, pickup_date, no_of_package, assured_dly_dt, delivery_dt, receiver_name)VALUES('$vehicle_type', '$consignment_number', '$origin', '$destination', '$pickup_date', '$no_of_package', '$assured_dly_dt', '$delivery_dt', '$receiver_name')");
	
	header("Location: ../consignment.php");
?>