<?php
    include '../function.php';
    $page_id = tres($_GET['page_id']);
    
    $con->query("DELETE FROM page WHERE page_id = '$page_id'");
    setMessage("Page deleted successfully", 'alert-success');
    header("Location: ../pages.php");
?>