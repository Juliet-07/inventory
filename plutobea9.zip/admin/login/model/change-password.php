<?php
    include '../function.php';
    $new_password = tres($_POST['password']);
    
    $con->query("UPDATE admin SET password = '$new_password' WHERE id = '".$_SESSION['admin_id']."'");
    setMessage('Password changed successfully', 'alert-success');
    header("Location: ../change-password.php");
?>