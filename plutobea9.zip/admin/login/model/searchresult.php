<?php
	include '../function.php';
	$str = tres($_POST['str']);
	$result_page = $con->query("SELECT * FROM page WHERE city LIKE '%$str%'");
	$i = 1;
	while($row_page = $result_page->fetch_assoc()){
?>
		<tr role="row" class="odd" style="color: <?php echo $color;?>;">
			<td><?php echo $i;?></td>
			<td><?php echo $row_page['page_id'];?></td>
			<td><?php echo $row_page['city'];?></td>
			<td><?php echo $row_page['page_view'];?></td>
			<td><?php echo $row_page['page_url'];?></td>
			<td><?php echo $row_page['status'];?></td>
			<td>
				<a href="./page-edit.php?page_id=<?php echo $row_page['page_id'];?>"><i class="fa fa-edit"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
				<a href="./model/page-delete.php?page_id=<?php echo $row_page['page_id'];?>" onclick="return confirm('Are you sure want to delete?');"><i class="fa fa-trash"></i></a>
			</td>
		</tr>
<?php $i++;}?>