<?php
	include '../function.php';
	$str = tres($_POST['str']);
	$result_order = $con->query("SELECT * FROM `consignment` WHERE consignment_number = '$str'");

	$i = 1;
	while ($row_news = $result_order->fetch_assoc()){
?>
		<tr role="row" class="odd" style="color: <?php echo $color;?>;">
			<td><?php echo $i;?></td>
			<td><?php echo $row_news['docket_number'];?></td>
			<td><?php echo $row_news['consignment_number'];?></td>
			<td><?php echo $row_news['origin'];?></td>
			<td><?php echo $row_news['destination'];?></td>
			<td><?php echo $row_news['pickup_date'];?></td>
			<td>
				<a href="consignment-edit.php?docket_number=<?php echo $row_news['docket_number'];?>"><i class="fa fa-edit"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
				<a href="./model/consignment-delete.php?docket_number=<?php echo $row_news['docket_number'];?>" onclick="return confirm('Are you sure want to delete?');"><i class="fa fa-trash"></i></a>
			</td>
		</tr>
<?php $i++;}?>