<?php
	include '../function.php';
	$order_id = tres($_POST['order_id']);
	
	$datetime = get_date().' '.get_time();
	$consignment_number = tres($_POST['consignment_number']);
	$amount = tres($_POST['amount']);
	$billing_name = tres($_POST['billing_name']);
	$billing_address = tres($_POST['billing_address']);
	$billing_city = tres($_POST['billing_city']);
	$billing_state = tres($_POST['billing_state']);
	$billing_zip = tres($_POST['billing_zip']);
	$billing_country = tres($_POST['billing_country']);
	$billing_tel = tres($_POST['billing_tel']);
	$billing_email = tres($_POST['billing_email']);
	
	$delivery_name = tres($_POST['delivery_name']);
	$delivery_address = tres($_POST['delivery_address']);
	$delivery_city = tres($_POST['delivery_city']);
	$delivery_state = tres($_POST['delivery_state']);
	$delivery_zip = tres($_POST['delivery_zip']);
	
	$delivery_country = tres($_POST['delivery_country']);
	$delivery_tel = tres($_POST['delivery_tel']);
	
	$con->query("UPDATE `order` SET consignment_number = '$consignment_number', amount = '$amount', billing_name = '$billing_name', billing_address = '$billing_address', billing_city = '$billing_city', billing_state = '$billing_state', billing_zip = '$billing_zip', billing_country = '$billing_country', billing_tel = '$billing_tel', billing_email = '$billing_email', delivery_name ='$delivery_name', delivery_address = '$delivery_address', delivery_city ='$delivery_city',delivery_state = '$delivery_state',delivery_zip = '$delivery_zip', delivery_country = '$delivery_country', delivery_tel = '$delivery_tel' WHERE order_id = '$order_id'");
	
	header("Location: ../order.php"); 
?>