<?php
	include '../function.php';
	$str = tres($_POST['str']);
	$result_order = $con->query("SELECT * FROM `order` WHERE consignment_number = '$str' ORDER BY order_id DESC  ");

	$i = 1;
	while ($row_news = $result_order->fetch_assoc()){
?>
		<tr role="row" class="odd" style="color: <?php echo $color;?>;">
			<td><?php echo $i;?></td>
			<td><?php echo $row_news['order_id'];?></td>
			<td><?php echo $row_news['consignment_number'];?></td>
			<td><?php echo $row_news['amount'];?></td>
			
			<td><?php echo $row_news['datetime'];?></td>
			<td><?php echo $row_news['payment_status'];?></td>
			<td>
				<a href="order-edit.php?order_id=<?php echo $row_news['order_id'];?>"><i class="fa fa-edit"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
				<a href="./model/order-delete.php?order_id=<?php echo $row_news['order_id'];?>" onclick="return confirm('Are you sure want to delete?');"><i class="fa fa-trash"></i></a>
			</td>
		</tr>
<?php $i++;}?>