<?php
    include '../function.php';
	
	$city = strtolower(tres($_POST['city']));
	$city_u = str_replace(' ', '-', $city);
	if($_POST['page_type']=='static'){
		$page_url = $city_u.'.html';
	}else{
		$page_url = 'packers-and-movers-'.$city_u.'.html';
	}
    
	
	$des = '<div>'.tres($_POST['description']).'</div>';
	$data = array(
		"page_type" =>tres($_POST['page_type']),
		"state_city" =>tres($_POST['state_city']),
		"city" =>tres($_POST['city']),
		"heading" => tres($_POST['heading']),
		"description" =>$des,
		"status" =>tres($_POST['status']),
		"meta_title" =>tres($_POST['meta_title']),
		"meta_keyword" =>tres($_POST['meta_keyword']),
		"meta_description" =>tres($_POST['meta_description']),
		"geo_region" =>tres($_POST['geo_region']),
		"geo_place" =>tres($_POST['geo_place']),
		"geo_position" =>tres($_POST['geo_position']),
		"icbm" =>tres($_POST['icbm']),
		"postal_code"=> tres($_POST['postal_code']),
		"street_address"=> tres($_POST['street_address']),
		"page_url"=> $page_url,
		"email"=>tres($_POST['email']),
		"phone_number"=>tres($_POST['phone_number'])
	);
    $page_id = insertData('page', $data);
    setMessage("Page Aded successfully", 'alert-success');
    header("Location: ../pages.php");
?>