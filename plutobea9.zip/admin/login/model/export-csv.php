<?php
	include '../function.php';
	$time = date('Y-m-d-H-i-s');
	
	$filename = '../files/page-'.$time.'.csv';
	$result = $con->query("SELECT * FROM  page");
	while($row = $result->fetch_assoc()){
		$arr = array(
			'city' => $row['city'],
			'heading' => $row['heading'],
			'page_url' => $row['page_url']
		);
		putToCsv($filename, $arr);
	}
	
	function putToCsv($filename, $arr){
		$fp = fopen($filename, 'a');
		fputcsv($fp, $arr);
		fclose($fp);
	}
	header("Location: $filename");
?>