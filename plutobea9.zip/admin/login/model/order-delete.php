<?php
	include '../function.php';
	$order_id = tres($_GET['order_id']);
	$con->query("DELETE FROM `order` WHERE order_id = '$order_id'");
	header("Location: ../order.php");
?>