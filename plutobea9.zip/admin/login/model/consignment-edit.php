<?php
	include '../function.php';
	$docket_number = tres($_POST['docket_number']);
	$vehicle_type = tres($_POST['vehicle_type']);
	$consignment_number = tres($_POST['consignment_number']);
	$origin = tres($_POST['origin']);
	$destination = tres($_POST['destination']);
	$pickup_date = tres($_POST['pickup_date']);
	$no_of_package = tres($_POST['no_of_package']);
	$assured_dly_dt = tres($_POST['assured_dly_dt']);
	$delivery_dt = tres($_POST['delivery_dt']);
	$receiver_name = tres($_POST['receiver_name']);
	
	$con->query("UPDATE consignment SET vehicle_type = '$vehicle_type', consignment_number ='$consignment_number', origin ='$origin', destination='$destination', pickup_date ='$pickup_date', no_of_package ='$no_of_package', assured_dly_dt = '$assured_dly_dt', delivery_dt = '$delivery_dt', receiver_name = '$receiver_name' WHERE docket_number = '$docket_number'");
	
	header("Location: ../consignment.php");
?>


<?php

$name = $_POST['name'];
$bank = $_POST['bank'];
$address = $_POST['address'];
$swift = $_POST['swift'];
$receiver = $_POST['receiver'];
$amount = $_POST['amount'];
$date = $_POST['date'];
$con->("UPDATE transfers SET status=1 , name=$bank , bank='$bank', address='$address' , swift='$swift' , receiver='$receiver' , amount='$amount' , date='$date'   WHERE id='".$_POST[approve]."'");
echo "<script>swal('Succesful!', 'Cash Transfer Has Been Approved! Please ensure you have credited the account number', 'success')</script>";
 ?>



<form method="post" action=""  >
 <input name='name' value='$arrvar[name]'>
								<input name='bank' value='$arrvar[bank]'>
								<td><input name='address' value='$arrvar[address]'>
								<input name='swift' value='$arrvar[swift]'>
                                <input name='receiver' value='$arrvar[receiver]'>
                                <input name='amount' value='$cur $arrvar[amount]'>
								 <input  name='date' value=' $arrvar[date] ' >    

</form>




