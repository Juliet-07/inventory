<?php
include('../../../register/connection.php');
// if(count($_POST)>0) {
// 	$sql = "UPDATE products set services='" . $_POST["services"] . "', category='" . $_POST["category"] . "', price='" . $_POST["price"] . "' WHERE id='" . $_POST["id"] . "'";
// 	mysqli_query($conn,$sql);
// 	$message = "Record Modified Successfully";
// }
// $select_query = "SELECT * FROM products WHERE id='" . $_GET["id"] . "'";
// $result = mysqli_query($conn,$select_query);
// $row = mysqli_fetch_array($result);
// if ($sql) {
//     echo "<script>alert('Updated successfully')</script>";
//     header("Location: tables.php");
//   }

// $category = $row['services'];



$Addons = "Add ons";
$body = "Body Sculpting & Skin Tightening";
$buttocks = "Buttocks & Breast Lifts";
$facials = "Facials";
$foot = "Foot & Hand Care";
$laser = "Laser Hair Removal";
$lashes = "Lashes";
$massage = "Massage";
$pmu = "PMU, Make-up & Eyebrow";
$skintt = "Skin Tightening Treatment";
$skint = "Skin Treatment";
$teeth = "Teeth Whitening";
$maxing = "Waxing (Hair Removal)";



if(count($_POST)>0) {
mysqli_query($conn,"UPDATE products set services='" . $_POST["services"] . "', category='" . $_POST["category"] . "', price='" . $_POST["price"] . "' WHERE services='" . $_POST['services'] . "'");
header("Location: tables.php");

}
$result = mysqli_query($conn,"SELECT * FROM products WHERE id='" . $_GET['id'] . "'");
$row= mysqli_fetch_array($result);
?>
<html>
<head>
<title>Update Price</title>
<meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="./assets/apple-icon.png" />
  <link rel="icon" type="image/png" href="./assets/favicon.ico" />
  <meta content="width=device-width, initial-scale=1.0, shrink-to-fit=no" name="viewport" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>PLUTOBEAUTY CAFE Admin</title>
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
  <!-- CSS Files -->
  <link href="/assets/css/material-dashboard.min.css?v=2.1.2" rel="stylesheet" />
  <link rel="stylesheet" href="../styles.css" />
  <link rel="stylesheet" href="table.css">
  <!-- JS Files -->
  <script src="https://code.jquery.com/jquery-1.10.1.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

  
</head>
<body>
  <div class="container">
    <div class="card text-center">
      <div class="card-body">
      <form name="frmUser" method="post" action="">

<input type="hidden" name="services" class="txtField" value="<?php echo $row['services']; ?>">
<input type="hidden" name="category" class="txtField" value="<?php echo $row['category']; ?>">

<h4 style="font-weight: 700;" class="bold">Category: <?php
                if ($row['category'] == 1) {
                  echo "$Addons";
                } elseif ($row['category'] == 2) {
                  echo "$body";
                }
                elseif ($row['category'] == 3) {
                  echo "$buttocks";
                }
                elseif ($row['category'] == 4) {
                  echo "$facials";
                }
                elseif ($row['category'] == 5) {
                  echo "$foot";
                }
                elseif ($row['category'] == 6) {
                  echo "$laser";
                }
                elseif ($row['category'] == 7) {
                  echo "$lashes";
                }
                elseif ($row['category'] == 8) {
                  echo "$massage";
                }
                elseif ($row['category'] == 9) {
                  echo "$pmu";
                }
                elseif ($row['category'] == 10) {
                  echo "$skintt";
                }
                elseif ($row['category'] == 11) {
                  echo "$skint";
                }
                elseif ($row['category'] == 12) {
                  echo "$teeth";
                }
                
                elseif ($row['category'] == 13) {
                  echo "$maxing";
                }



                ?></h4>  
<h4 style="font-weight: 700;">Service:  <span><?php echo $row['services']; ?></span></h4>

<h4 style="font-weight: 700;"> Price: <span><input type="text" name="price" class="txtField" value="<?php echo $row['price']; ?>">
</span></h4>




<br>
<input type="submit" name="submit" value="Update" class="btn ">

</form>
<a href="tables.php" style="font-size:20px;" class="py-4 my-4 text-white"> Go Back</a>

      </div>
    </div>

  </div>

</body>
</html>