<?php
session_start();
error_reporting(0);
include('../../../register/connection.php');

// $m=date("Y-m-d");

if (!isset($_SESSION["admin"])) {
  header("Location: ../../index.php");
}

$admin = $_SESSION['admin'];


$result = mysqli_query($conn,"SELECT * FROM products order by abs(category)");

$Addons = "Add ons";
$body = "Body Sculpting & Skin Tightening";
$buttocks = "Buttocks & Breast Lifts";
$facials = "Facials";
$foot = "Foot & Hand Care";
$laser = "Laser Hair Removal";
$lashes = "Lashes";
$massage = "Massage";
$pmu = "PMU, Make-up & Eyebrow";
$skintt = "Skin Tightening Treatment";
$skint = "Skin Treatment";
$teeth = "Teeth Whitening";
$maxing = "Waxing (Hair Removal)";




//Code for deletion
if (isset($_GET['delid'])) {
  $rid = intval($_GET['delid']);
  $sql = mysqli_query($con, "delete from tblusers where ID=$rid");
  echo "<script>alert('Data deleted');</script>";
  echo "<script>window.location.href = 'index.php'</script>";
}

// if (isset($_POST['update'])) {
// 	$id = $_POST['id'];
//   $service = $_POST['service'];
// 	$price = $_POST['price'];
//   $category = $_POST['category'];
	//$address = $_POST['address'];

// $sql =	mysqli_query($conn, "UPDATE products SET price='$price' WHERE id=$id");

// if ($sql) {
//   echo "<script>alert('Updated successfully')</script>";
//   header("Location: tables.php");
// }

// else {
//   echo "<script>alert('update failed')</script>";
// }

// }


?>



<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="./assets/apple-icon.png" />
  <link rel="icon" type="image/png" href="./assets/favicon.ico" />
  <meta content="width=device-width, initial-scale=1.0, shrink-to-fit=no" name="viewport" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>PLUTOBEAUTY CAFE Admin</title>
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
  <!-- CSS Files -->
  <link href="/assets/css/material-dashboard.min.css?v=2.1.2" rel="stylesheet" />
  <link rel="stylesheet" href="../styles.css" />
  <link rel="stylesheet" href="table.css">
  <!-- JS Files -->
  <script src="https://code.jquery.com/jquery-1.10.1.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

 
</head>

<body>
  <div class="wrapper">
    <div class="sidebar" data-color="purple" data-background-color="white">
      <div class="logo">
        <a href="#" class="simple-text logo-normal">
          PLUTOBEAUTY CAFE </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item">
            <a class="nav-link" href="../index.php">
              <i class="material-icons">dashboard</i>
              <p>Dashboard</p>
            </a>
          </li>
          <li class="nav-item">
              <a class="nav-link" href="../user.php">
                <i class="material-icons">person</i>
                <p> Register Employee</p>
              </a>
            </li>
          <li class="nav-item">
            <a class="nav-link" href="../makeadmin.php">
              <i class="material-icons">account_circle</i>
              <p>Employee List</p>
            </a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="./tables.php">
              <i class="material-icons">content_paste</i>
              <p>Change Prices</p>
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="../report.php">
              <i class="material-icons">report</i>
              <p>Report</p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../changepassword.php">
              <i class="material-icons">lock</i>
              <p>Change Password</p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../logout.php">
              <i class="material-icons">logout</i>
              <p>Logout</p>
            </a>
          </li>
        </ul>
      </div>
    </div>
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a class="navbar-brand" href="javascript:;">Change Prices</a>
          </div>
      </nav>
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Change Prices of Services</h4>

                </div>
                <div class="card-body">
                  


                  <div class="card-body">
                  <div class="table-responsive">
                  <?php
if (mysqli_num_rows($result) > 0) {
?>
                    <table class="table">
                      <thead>
                        <tr class="text-primary">
                          
                          <th>CATEGORY</th>
                          <th>SERVICE</th>
                          <th>PRICE</th>
                          <th></th>
                        </tr>
                      </thead>

                      <tbody>
                        <form action="" method="POST">
                        <?php
			$i=0;
			while($row = mysqli_fetch_array($result)) {
			?>
	  <tr>
		<td><?php
                if ($row['category'] == 1) {
                  echo "$Addons";
                } elseif ($row['category'] == 2) {
                  echo "$body";
                }
                elseif ($row['category'] == 3) {
                  echo "$buttocks";
                }
                elseif ($row['category'] == 4) {
                  echo "$facials";
                }
                elseif ($row['category'] == 5) {
                  echo "$foot";
                }
                elseif ($row['category'] == 6) {
                  echo "$laser";
                }
                elseif ($row['category'] == 7) {
                  echo "$lashes";
                }
                elseif ($row['category'] == 8) {
                  echo "$massage";
                }
                elseif ($row['category'] == 9) {
                  echo "$pmu";
                }
                elseif ($row['category'] == 10) {
                  echo "$skintt";
                }
                elseif ($row['category'] == 11) {
                  echo "$skint";
                }
                elseif ($row['category'] == 12) {
                  echo "$teeth";
                }
                
                elseif ($row['category'] == 13) {
                  echo "$maxing";
                }



                ?></td>
		<td><?php echo $row["services"]; ?></td>
		<td><?php echo $row["price"]; ?></td>
		<td><a href="update.php?id=<?php echo $row["id"]; ?>">Update</a></td>
      </tr>
			<?php
			$i++;
			}
			?>
</table>
 <?php
}
else
{
    echo "No result found";
}
?>

                        </form>

                      </tbody>
                    </table>

                  </div>
                </div>
              </div>
            </div>
            <!--   Core JS Files   -->
            <script src="./table.js"></script>
</body>

</html>