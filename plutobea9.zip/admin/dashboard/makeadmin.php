<?php
session_start();
error_reporting(0);
include('../../register/connection.php');

// $m=date("Y-m-d");

if (!isset($_SESSION["admin"])) {
  header("Location: ../index.php");
}

$admin = $_SESSION['admin'];




//Code for deletion
if (isset($_GET['delid'])) {
  $rid = intval($_GET['delid']);
  $sql = mysqli_query($con, "delete from tblusers where ID=$rid");
  echo "<script>alert('Data deleted');</script>";
  echo "<script>window.location.href = 'index.php'</script>";
}


?>





<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="./assets/apple-icon.png" />
  <link rel="icon" type="image/png" href="./assets/favicon.ico" />
  <meta content="width=device-width, initial-scale=1.0, shrink-to-fit=no" name="viewport" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>PLUTOBEAUTY CAFE Admin</title>
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
  <!-- CSS Files -->
  <link href="/assets/css/material-dashboard.min.css?v=2.1.2" rel="stylesheet" />
  <link rel="stylesheet" href="./styles.css" />
  <link rel="stylesheet" href="./table/table.css" />
</head>

<body>
  <div class="wrapper">
    <div class="sidebar" data-color="purple" data-background-color="white">
      <div class="logo">
        <a href="#" class="simple-text logo-normal"> PLUTOBEAUTY CAFE </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item">
            <a class="nav-link" href="index.php">
              <i class="material-icons">dashboard</i>
              <p>Dashboard</p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="user.php">
              <i class="material-icons">person</i>
              <p>Register Employee</p>
            </a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="makeadmin.php">
              <i class="material-icons">account_circle</i>
              <p>Employee List</p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="./table/tables.php">
              <i class="material-icons">content_paste</i>
              <p>Change Prices</p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="report.php">
              <i class="material-icons">report</i>
              <p>Report</p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="changepassword.php">
              <i class="material-icons">lock</i>
              <p>Change Password</p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="logout.php">
              <i class="material-icons">logout</i>
              <p>Logout</p>
            </a>
          </li>
        </ul>
      </div>
    </div>
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a class="navbar-brand" href="javascript:;">Employee List</a>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
          <div class="card">
            <div class="card-header card-header-primary">
              <h4 class="card-title">
                List of all registrered employees
              </h4>
              <!-- <p class="card-category">Created using Roboto Font Family</p> -->
            </div>
            <div class="card-body">
              <!-- <h1>Table here</h1> -->
              <div class="table-responsive">
                <table class="table ">
                  <thead class="text-primary">
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Username</th>
                    <th>Phone</th>
                    <th>Branch</th>
                    <th>Delete</th>
                  </thead>
                  <tbody>

                    <?php
                    $users = mysqli_query($conn, "select * from users order by id ");
                    $cnt = 1;
                    $row = mysqli_num_rows($users);
                    if ($row > 0) {
                      while ($row = mysqli_fetch_array($users)) {
                    ?>
                        <!--Fetch the Records -->
                        <tr>
                          <td><?php echo $cnt; ?></td>
                          <td><?php echo $row['fullname']; ?>
                          <td><?php echo $row['email']; ?></td>
                          <td><?php echo $row['username']; ?></td>
                          <td><?php echo $row['mobile']; ?></td>
                          <td><?php echo $row['branch']; ?></td>

                          <td>


                            

<a onclick='return confirm("Are you sure you want to delete user?")' href='delete.php?id=<?php echo $row['id'];?>'>
<span style="color:red;" class="material-icons">clear</span></a>
                            <!-- <a href="#del" data-toggle="modal" class="btn" >
                                  <span style="color:red;" class="material-icons">clear</span></a>
                                 -->
                          </td>
                        </tr>
                      <?php
                        $cnt = $cnt + 1;
                      }
                    } else { ?>
                      <tr>
                        <th style="text-align:center; color:red;" colspan="6">No Record Found</th>
                      </tr>
                    <?php } ?>



                  </tbody>

                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>

</html>