<?php
session_start();
error_reporting(0);
include('../../register/connection.php');

// $m=date("Y-m-d");

if (!isset($_SESSION["admin"])) {
  header("Location: ../index.php");
}

$admin = $_SESSION['admin'];




//Code for deletion
// if (isset($_GET['delid'])) {
//   $rid = intval($_GET['delid']);
//   $sql = mysqli_query($con, "delete from users where ID=$rid");
//   echo "<script>alert('Data deleted');</script>";
//   echo "<script>window.location.href = 'index.php'</script>";
// } else {
//   echo "<script>alert('Sales record failed')</script>";
// }






if (isset($_POST['class_name'], $_POST['rno'])) {
  $class_name = $_POST['class_name'];
  $rno = $_POST['rno'];
  echo $class_name;
  echo $rno;
  $delete_sql = mysqli_query($conn, "DELETE from `result` where `rno`='$rno' and `class`='$class_name'");
  if (!$delete_sql) {
    echo '<script language="javascript">';
    echo 'alert("Not available")';
    echo '</script>';
  } else {
    echo '<script language="javascript">';
    echo 'alert("Deleted")';
    echo '</script>';
  }
}


?>



<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="./assets/apple-icon.png" />
  <link rel="icon" type="image/png" href="./assets/favicon.ico" />
  <meta content="width=device-width, initial-scale=1.0, shrink-to-fit=no" name="viewport" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title> PLUTOBEAUTY CAFE Admin</title>
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
  <!-- CSS Files -->
  <link href="/assets/css/material-dashboard.min.css?v=2.1.2" rel="stylesheet" />
  <link rel="stylesheet" href="./styles.css" />
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>

<body>
  <div class="wrapper">
    <div class="sidebar" data-color="orange" data-background-color="white">
      <div class="logo">
        <a href="#" class="simple-text logo-normal">
          PLUTOBEAUTY CAFE
        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item active">
            <a class="nav-link" href="#">
              <i class="material-icons">dashboard</i>
              <p>Dashboard</p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="user.php">
              <i class="material-icons">person</i>
              <p>Register Employee</p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="makeadmin.php">
              <i class="material-icons">account_circle</i>
              <p>Employee List</p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="./table/tables.php">
              <i class="material-icons">content_paste</i>
              <p>Change Prices</p>
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="report.php">
              <i class="material-icons">report</i>
              <p>Report</p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="changepassword.php">
              <i class="material-icons">lock</i>
              <p>Change Password</p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="logout.php">
              <i class="material-icons">logout</i>
              <p>Logout</p>
            </a>
          </li>
        </ul>
      </div>
    </div>
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a class="navbar-brand" href="javascript:;">Dashboard</a>
          </div>
      </nav>
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">


          <!-- SALES STATISTICS -->
          <div class="row">
            <div class="col-md-4">
              <div class="card card-chart">
                <div class="card-header card-header-success">
                  <div class="ct-chart" id="dailySalesChart">
                    <h4 class="card-title">Daily Sales</h4>
                  </div>
                </div>
                <div class="card-body">
                  <h3 class="bolder text-center mt-1">Total Amount</h3>
                  <?php

                  $sumup = mysqli_query($conn, "SELECT SUM(price) AS totalsum FROM sales where date(datetime) = date(now())");
                  $amt = mysqli_fetch_row($sumup);
                  $sum = $amt[0];

                  $c1 = mysqli_num_rows($s);

                  if ($sumup) {
                    echo "  <span align='center'><h2>$c1</h2> 
                    <h2 style='color:green; font-weight:bold;'>&#8358 $sum </h2>
                    </span> ";
                  } else {
                    echo "<h1 style='color:green; font-weight:bold; text-align:center;'>&#8358 0 </h1>";
                  }
                  ?>
                </div>
                <div class="card-footer">
                  <div class="stats">
                    <i class="material-icons">access_time</i>Updates according to how the workers record sales
                  </div>
                </div>
              </div>
            </div>

            <div class="col-md-4">
              <div class="card card-chart">
                <div class="card-header card-header-warning">
                  <div class="ct-chart" id="websiteViewsChart">
                    <h4 class="card-title">Weekly Sales</h4>
                  </div>
                </div>
                <div class="card-body">
                  <h3 class="bolder text-center mt-1">Total Amount</h3>
                  <?php

                  $sumup = mysqli_query($conn, "SELECT SUM(price) AS totalsum FROM sales where yearweek(datetime) = yearweek(now())");
                  $amt = mysqli_fetch_row($sumup);
                  $sum = $amt[0];

                  $c1 = mysqli_num_rows($s);

                  if ($sumup) {
                    echo "  <span align='center'><h2>$c1</h2> 
                    <h2 style='color:green; font-weight:bold;'>&#8358 $sum </h2>
                    </span> ";
                  } else {
                    echo "<h1 style='color:green; font-weight:bold; text-align:center;'>&#8358 0 </h1>";
                  }
                  ?>
                </div>
                <div class="card-footer">
                  <div class="stats">
                    <i class="material-icons">access_time</i>Updates every Friday
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="card card-chart">
                <div class="card-header card-header-primary">
                  <div class="ct-chart" id="completedTasksChart">
                    <h4 class="card-title">Monthly Sales</h4>
                  </div>
                </div>
                <div class="card-body">
                  <h3 class="bolder text-center mt-1">Total Amount</h3>
                  <?php

                  $sumup = mysqli_query($conn, "SELECT SUM(price) AS totalsum FROM sales WHERE MONTH(datetime) = MONTH(CURDATE())");
                  $amt = mysqli_fetch_row($sumup);
                  $sum = $amt[0];

                  $c1 = mysqli_num_rows($s);

                  if ($sumup) {
                    echo "  <span align='center'><h2>$c1</h2> 
                    <h2 style='color:green; font-weight:bold;'>&#8358 $sum </h2>
                    </span> ";
                  } else {
                    echo "<h1 style='color:green; font-weight:bold; text-align:center;'>&#8358 0 </h1>";
                  }
                  ?>
                </div>
                <div class="card-footer">
                  <div class="stats">
                    <i class="material-icons">access_time</i>Updates on the 1st day of every month
                  </div>
                </div>
              </div>
            </div>
          </div>



          <!-- CARDS -->
          <div class="row">

            <!-- CARD FOR EMPLOYEE STATISTICS -->
            <div class="col-lg-12 col-md-12">
              <div class="card">
                <div class="card-header card-header-warning">
                  <h4 class="card-title">Employees List</h4>
                </div>
                <div class="card-body table-responsive">
                  <div class="table-responsive">
                    <table class="table ">
                      <thead class="text-primary">
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Username</th>
                        <th>Phone</th>
                        <th>Branch</th>
                        <th>Delete</th>
                      </thead>
                      <tbody>

                        <?php
                        $users = mysqli_query($conn, "select * from users order by id ");
                        $cnt = 1;
                        $row = mysqli_num_rows($users);
                        if ($row > 0) {
                          while ($row = mysqli_fetch_array($users)) {
                        ?>
                            <!--Fetch the Records -->
                            <tr>
                              <td><?php echo $cnt; ?></td>
                              <td><?php echo $row['fullname']; ?>
                              <td><?php echo $row['email']; ?></td>
                              <td><?php echo $row['username']; ?></td>
                              <td><?php echo $row['mobile']; ?></td>
                              <td><?php echo $row['branch']; ?></td>

                              <td>
  
                         

<a onclick='return confirm("Are you sure you want to delete user?")' href='delete.php?id=<?php echo $row['id'];?>'>
<span style="color:red;" class="material-icons">clear</span></a>


                                <!-- <a href="#del" data-toggle="modal" class="btn" >
                                  <span style="color:red;" class="material-icons">clear</span></a>
                                 -->
                              </td>
                            </tr>
                          <?php
                            $cnt = $cnt + 1;
                          }
                        } else { ?>
                          <tr>
                            <th style="text-align:center; color:red;" colspan="6">No Record Found</th>
                          </tr>
                        <?php } ?>



                      </tbody>

                    </table>
                  </div>
         



                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
  <!--   Core JS Files   -->
  <script src="../assets/js/core/jquery.min.js"></script>
  <script src="../assets/js/core/popper.min.js"></script>
  <script src="../assets/js/core/bootstrap-material-design.min.js"></script>
  <script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!-- Plugin for the momentJs  -->
  <script src="../assets/js/plugins/moment.min.js"></script>
  <!--  Plugin for Sweet Alert -->
  <script src="../assets/js/plugins/sweetalert2.js"></script>
  <!-- Forms Validations Plugin -->
  <script src="../assets/js/plugins/jquery.validate.min.js"></script>
  <!-- Plugin for the Wizard, full documentation here: https://github.com/VinceG/twitter-bootstrap-wizard -->
  <script src="../assets/js/plugins/jquery.bootstrap-wizard.js"></script>
  <!--	Plugin for Select, full documentation here: http://silviomoreto.github.io/bootstrap-select -->
  <script src="../assets/js/plugins/bootstrap-selectpicker.js"></script>
  <!--  Plugin for the DateTimePicker, full documentation here: https://eonasdan.github.io/bootstrap-datetimepicker/ -->
  <script src="../assets/js/plugins/bootstrap-datetimepicker.min.js"></script>
  <!--  DataTables.net Plugin, full documentation here: https://datatables.net/  -->
  <script src="../assets/js/plugins/jquery.dataTables.min.js"></script>
  <!--	Plugin for Tags, full documentation here: https://github.com/bootstrap-tagsinput/bootstrap-tagsinputs  -->
  <script src="../assets/js/plugins/bootstrap-tagsinput.js"></script>
  <!-- Plugin for Fileupload, full documentation here: http://www.jasny.net/bootstrap/javascript/#fileinput -->
  <script src="../assets/js/plugins/jasny-bootstrap.min.js"></script>
  <!--  Full Calendar Plugin, full documentation here: https://github.com/fullcalendar/fullcalendar    -->
  <script src="../assets/js/plugins/fullcalendar.min.js"></script>
  <!-- Vector Map plugin, full documentation here: http://jvectormap.com/documentation/ -->
  <script src="../assets/js/plugins/jquery-jvectormap.js"></script>
  <!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
  <script src="../assets/js/plugins/nouislider.min.js"></script>
  <!-- Include a polyfill for ES6 Promises (optional) for IE11, UC Browser and Android browser support SweetAlert -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>
  <!-- Library for adding dinamically elements -->
  <script src="../assets/js/plugins/arrive.min.js"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB2Yno10-YTnLjjn_Vtk0V8cdcY5lC4plU"></script>
  <!-- Place this tag in your head or just before your close body tag. -->
  <script async defer src="https://buttons.github.io/buttons.js"></script>
  <!-- Chartist JS -->
  <script src="./assets/js/plugins/chartist.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="../assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="../assets/js/material-dashboard.min.js?v=2.1.2" type="text/javascript"></script>
</body>

</html>