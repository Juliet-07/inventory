<?php
session_start();
error_reporting(0);
include('../../register/connection.php');

// $m=date("Y-m-d");

if (!isset($_SESSION["admin"])) {
  header("Location: ../index.php");
}

$admin = $_SESSION['admin'];

// If form submitted, insert values into the database.
if (isset($_REQUEST['username'])){
  
  $fullname = stripslashes($_REQUEST['fullname']);
  $fullname = mysqli_real_escape_string($conn,$fullname);

$email = stripslashes($_REQUEST['email']);
$email = mysqli_real_escape_string($conn,$email);
$mobile = stripslashes($_REQUEST['mobile']);
$mobile = mysqli_real_escape_string($conn,$mobile);
$username = stripslashes($_REQUEST['username']);
$username = mysqli_real_escape_string($conn,$username);
$branch = stripslashes($_REQUEST['branch']);
$branch = mysqli_real_escape_string($conn,$branch);  
$password = stripslashes($_REQUEST['password']);
$password = mysqli_real_escape_string($conn,$password);
$query = "INSERT into `users` (fullname, email, mobile, username,  password, branch)
VALUES ('$fullname',  '$email', '$mobile', '$username', '$password', '$branch')";
  $result = mysqli_query($conn,$query);
  if($result){
  
  echo "<script>alert('Registration successful');</script>";
  echo "<script>window.location.href = 'user.php'</script>";
  //header("Location: user.php");
}
else{
  echo "<script>alert('Registration failed')
  </script>";
}

}

?>




<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <link rel="apple-touch-icon" sizes="76x76" href="./assets/apple-icon.png" />
        <link rel="icon" type="image/png" href="./assets/favicon.ico" />
        <meta
          content="width=device-width, initial-scale=1.0, shrink-to-fit=no"
          name="viewport"
        />
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <title>PLUTOBEAUTY CAFE Admin</title>
        <!--     Fonts and icons     -->
        <link
          rel="stylesheet"
          type="text/css"
          href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons"
        />
        <link
          rel="stylesheet"
          href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css"
        />
        <!-- CSS Files -->
        <link
          href="/assets/css/material-dashboard.min.css?v=2.1.2"
          rel="stylesheet"
        />
        <link rel="stylesheet" href="./styles.css" />
      </head>
  <body>
    <div class="wrapper">
      <div
        class="sidebar"
        data-color="purple"
        data-background-color="white"
      >
        <div class="logo">
          <a href="#" class="simple-text logo-normal">
          PLUTOBEAUTY CAFE          </a>
        </div>
        <div class="sidebar-wrapper">
          <ul class="nav">
            <li class="nav-item">
              <a class="nav-link" href="index.php">
                <i class="material-icons">dashboard</i>
                <p>Dashboard</p>
              </a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="user.php">
                <i class="material-icons">person</i>
                <p> Register Employee</p>
              </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="makeadmin.php">
                  <i class="material-icons">account_circle</i>
                  <p>Employee List</p>
                </a>
              </li>
            <li class="nav-item">
                <a class="nav-link" href="./table/tables.php">
                  <i class="material-icons">content_paste</i>
                  <p>Change Prices</p>
                </a>
              </li>             
              <li class="nav-item">
                <a class="nav-link" href="report.php">
                  <i class="material-icons">report</i>
                  <p>Report</p>
                </a>
              </li>
              <li class="nav-item">
            <a class="nav-link" href="changepassword.php">
              <i class="material-icons">lock</i>
              <p>Change Password</p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="logout.php">
              <i class="material-icons">logout</i>
              <p>Logout</p>
            </a>
          </li>
          </ul>
        </div>
      </div>
      <div class="main-panel">
        <!-- Navbar -->
        <nav
          class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top"
        >
          <div class="container-fluid">
            <div class="navbar-wrapper">
              <a class="navbar-brand" href="javascript:;"> Register Employee</a>
            </div>
        </nav>
        <!-- End Navbar -->
        <div class="content">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-8">
                <div class="card">
                  <div class="card-header card-header-primary">
                    <h4 class="card-title">Register</h4>
                    <p class="card-category">Complete profile</p>
                  </div>
                  <div class="card-body">
                    <form method="POST" action="">
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group">
                            <label class="bmd-label-floating">Full Name</label>
                            <input type="text" class="form-control" name="fullname" required="required"/>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label class="bmd-label-floating">Email</label>
                            <input type="text" class="form-control" name="email" required="required"/>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group">
                            <label class="bmd-label-floating">Username</label>
                            <input type="text" class="form-control" name="username" required="required"/>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label class="bmd-label-floating">Phone number</label>
                            <input type="phone" class="form-control" name="mobile" required="required"/>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group">
                            <label class="bmd-label-floating">Password</label>
                            <input type="password" class="form-control" name="password" required="required"/>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label class="bmd-label-floating">Confirm Password</label>
                            <input type="password" class="form-control" name="confirm_password" required="required" />
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                          <div class="form-group">
                            <label class="bmd-label-floating">Branch Name</label>
                            <input type="text" class="form-control" name="branch" required="required"/>
                          </div>
                        </div>
                      <button type="submit" name="submit" class="btn btn-primary pull-right">
                        Submit
                      </button>
                      <div class="clearfix"></div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        </div>
    </div>
    </body>
</html>
