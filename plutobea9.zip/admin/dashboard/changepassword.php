<?php
session_start();
error_reporting(0);
include('../../register/connection.php');

// $m=date("Y-m-d");

if (!isset($_SESSION["admin"])) {
  header("Location: ../index.php");
}

$admin = $_SESSION['admin'];




//Code for deletion
if (isset($_GET['delid'])) {
  $rid = intval($_GET['delid']);
  $sql = mysqli_query($con, "delete from tblusers where ID=$rid");
  echo "<script>alert('Data deleted');</script>";
  echo "<script>window.location.href = 'index.php'</script>";
}



$_SESSION["userId"] = "1";

if (count($_POST) > 0) {
    $result = mysqli_query($conn, "SELECT *from admin WHERE id='" . $_SESSION["userId"] . "'");
    $row = mysqli_fetch_array($result);
    if ($_POST["opwd"] == $row["password"]) {
        mysqli_query($conn, "UPDATE admin set password='" . $_POST["npwd"] . "' WHERE id='" . $_SESSION["userId"] . "'");
        $message = "Password Changed";
    } else
        $message = "Old Password is not correct";
}



?>





<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <link rel="apple-touch-icon" sizes="76x76" href="./assets/apple-icon.png" />
        <link rel="icon" type="image/png" href="./assets/favicon.ico" />
        <meta
          content="width=device-width, initial-scale=1.0, shrink-to-fit=no"
          name="viewport"
        />
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <title>PLUTOBEAUTY CAFE Admin</title>
        <!--     Fonts and icons     -->
        <link
          rel="stylesheet"
          type="text/css"
          href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons"
        />
        <link
          rel="stylesheet"
          href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css"
        />
        <!-- CSS Files -->
        <link
          href="/assets/css/material-dashboard.min.css?v=2.1.2"
          rel="stylesheet"
        />
        <link rel="stylesheet" href="./styles.css" />
      </head>
  <body>
    <div class="wrapper">
      <div
        class="sidebar"
        data-color="purple"
        data-background-color="white"
      >
        <div class="logo">
          <a href="#" class="simple-text logo-normal">
          PLUTOBEAUTY CAFE          </a>
        </div>
        <div class="sidebar-wrapper">
          <ul class="nav">
            <li class="nav-item">
              <a class="nav-link" href="index.php">
                <i class="material-icons">dashboard</i>
                <p>Dashboard</p>
              </a>
            </li>
            <!-- <li class="nav-item active">
              <a class="nav-link" href="user.php">
                <i class="material-icons">person</i>
                <p> Profile</p>
              </a>
            </li> -->
            <li class="nav-item">
                <a class="nav-link" href="./table/tables.php">
                  <i class="material-icons">content_paste</i>
                  <p>Change Prices</p>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="makeadmin.php">
                  <i class="material-icons">account_circle</i>
                  <p>Employee List</p>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="report.php">
                  <i class="material-icons">report</i>
                  <p>Report</p>
                </a>
              </li>
              <li class="nav-item">
            <a class="nav-link" href="changepassword.php">
              <i class="material-icons">lock</i>
              <p>Change Password</p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="logout.php">
              <i class="material-icons">logout</i>
              <p>Logout</p>
            </a>
          </li>
          </ul>
        </div>
      </div>
      <div class="main-panel">
        <!-- Navbar -->
        <nav
          class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top"
        >
          <div class="container-fluid">
            <div class="navbar-wrapper">
              <a class="navbar-brand" href="javascript:;"> Change Password</a>
            </div>
        </nav>
        <!-- End Navbar -->
        <div class="content">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-8">
                <div class="card">
                  <div class="card-header card-header-primary">
                    <h4 class="card-title">Change Admin Password</h4>
                  </div>
                  <div class="card-body">
                  <div class="message"><?php if(isset($message)) { echo $message; } ?></div>
                    <form method="POST" action="">
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group">
                            <label class="bmd-label-floating">Old password</label>
                            <input type="password" name="opwd" class="form-control" />
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label class="bmd-label-floating">New Password</label>
                            <input type="password" name="npwd" class="form-control" />
                          </div>
                        </div>
                        <div class="form-group pl-4">
                            <label class="bmd-label-floating">Confirm New Password</label>
                            <input type="password" name="cpwd" class="form-control" />
                          </div>
                      </div>
                      <button type="submit" class="btn btn-primary pull-right">
                        Submit
                      </button>

                          </div>
                        </div>
                      </div>
                      
                      <div class="clearfix"></div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        </div>
    </div>


    <script>
    if (window.history.replaceState) {
      window.history.replaceState(null, null, window.location.href);
    }
  </script>
    </body>
</html>
