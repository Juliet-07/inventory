<?php
session_start();
error_reporting(0);
include('../../register/connection.php');

// $m=date("Y-m-d");

if (!isset($_SESSION["admin"])) {
  header("Location: ../index.php");
}

$admin = $_SESSION['admin'];




//Code for deletion
if (isset($_GET['delid'])) {
  $rid = intval($_GET['delid']);
  $sql = mysqli_query($con, "delete from tblusers where ID=$rid");
  echo "<script>alert('Data deleted');</script>";
  echo "<script>window.location.href = 'index.php'</script>";
}


?>



<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="./assets/apple-icon.png" />
  <link rel="icon" type="image/png" href="./assets/favicon.ico" />
  <meta content="width=device-width, initial-scale=1.0, shrink-to-fit=no" name="viewport" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>PLUTOBEAUTY CAFE Admin</title>
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
  <!-- CSS Files -->
  <link href="/assets/css/material-dashboard.min.css?v=2.1.2" rel="stylesheet" />
  <link rel="stylesheet" href="./styles.css" />
  <link rel="stylesheet" href="/table/table.css">
  <!-- JS -->
  <script src="https://code.jquery.com/jquery-1.10.1.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>

<body>
  <div class="wrapper">
    <div class="sidebar" data-color="purple" data-background-color="white">
      <div class="logo">
        <a href="#" class="simple-text logo-normal">
          PLUTOBEAUTY CAFE
        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item">
            <a class="nav-link" href="index.php">
              <i class="material-icons">dashboard</i>
              <p>Dashboard</p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="user.php">
              <i class="material-icons">person</i>
              <p>Register Employee</p>
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="makeadmin.php">
              <i class="material-icons">account_circle</i>
              <p>Employee List</p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="./table/tables.php">
              <i class="material-icons">content_paste</i>
              <p>Change Prices</p>
            </a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="report.php">
              <i class="material-icons">report</i>
              <p>Report</p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="changepassword.php">
              <i class="material-icons">lock</i>
              <p>Change Password</p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="logout.php">
              <i class="material-icons">logout</i>
              <p>Logout</p>
            </a>
          </li>
        </ul>
      </div>
    </div>
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a class="navbar-brand" href="javascript:;">Report</a>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
          <div class="card card-plain">
            <div class="card-header card-header-success">
              <h4 class="card-title">Daily Report</h4>
            </div>
            <div class="card">


              <div class="card-body">
                <table class="table table-striped table-valign-middle">
                  <thead>
                    <tr class="text-primary ">
                      <th>Employee</th>
                      <th>Branch</th>
                      <th>Category</th>
                      <th>Services</th>
                      <th>Amount</th>
                      <th>Customer</th>
                      <th>Phone</th>
                      <th>Date & Time</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    $sales = mysqli_query($conn, "select * from sales where date(datetime) = date(now()) order by id desc");
                    while ($adetails = mysqli_fetch_array($sales)) {

                      $branch = $adetails['branch'];
                      $services = $adetails['services'];
                      $category = $adetails['category'];
                      $price = $adetails['price'];
                      $staff = $adetails['sales_rep'];
                      $customer = $adetails['customer'];
                      $phone = $adetails['phone'];
                      // $date = $adetails['date'];
                      $datetime = $adetails['datetime'];

                    ?>


                      <?php
                      echo "<tr>          
                <td>
                 $staff
                 </td>
                 <td>
                 $branch
                 </td>
                    <td>
                      $category
                    </td>
                    <td>
                     $services
                    </td>
                    <td style='font-weight:bold; color:green;'>$price </td>
                    <td>
                    $customer
                  </td>
                  <td>
                   $phone
                  </td>
                    <td>
                     $datetime
                    </td>
                                       
                  </tr>
                  ";  ?>
                    <?php
                    }
                    ?>

                  </tbody>
                </table>
                <?php

                $sumup = mysqli_query($conn, "SELECT SUM(price) AS totalsum FROM sales where date(datetime) = date(now())");
                $amt = mysqli_fetch_row($sumup);
                $sum = $amt[0];

                $c1 = mysqli_num_rows($s);



                echo "  <span align='center'><h2>$c1</h2> 
 <h4 style='color:green; font-weight:bold;'>Total Amount - &#8358 $sum </h4>
 </span> ";
                ?>
              </div>
            </div>
          </div>
          <!-- WEEKLY -->
          <div class="card card-plain">
            <div class="card-header card-header-warning">
              <h4 class="card-title">Weekly Report</h4>
            </div>
            <div class="card">


              <div class="card-body">
                <table class="table table-striped table-valign-middle">
                  <thead>
                    <tr class="text-primary ">
                      <th>Category</th>
                      <th>Amount</th>
                      <th>Date & Time</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    $sales2 = mysqli_query($conn, "select * from sales where yearweek(datetime) = yearweek(now()) order by id desc");
                    while ($bdetails = mysqli_fetch_array($sales2)) {


                      $category2 = $bdetails['category'];
                      $services2 = $bdetails['services'];
                      // $category = $adetails['category'];
                      $price2 = $bdetails['price'];
                      $staff = $bdetails['sales_rep'];
                      // $date = $adetails['date'];

                      $datetime = $bdetails['datetime'];
                    ?>


                      <?php
                      echo "<tr>          
        <td>
        $category2
      </td>
           
      <td style='font-weight:bold; color:green;'>$price2 </td>
      <td>
       $datetime
      </td>
                         
    </tr>
    ";  ?>
                    <?php
                    }
                    ?>

                  </tbody>
                </table>
                <?php

                //   $sumup = mysqli_query($conn, "select category, SUM(price) AS Total1 from sales group by category ");
                //   while($row = mysqli_fetch_array($sumup)){

                //     echo "<tr>"; 
                //   echo "<td>" . $row['category'] . "</td>";
                //   echo "<td>" . $row['Total1'] . "</td>";
                //   echo "</tr>"; 
                // }





                $sumup = mysqli_query($conn, "SELECT SUM(price) AS totalsum FROM sales where yearweek(datetime) = yearweek(now())");
                $amt = mysqli_fetch_row($sumup);
                $sum = $amt[0];

                $c1 = mysqli_num_rows($s);

                if ($sumup) {
                  echo "  <span align='center'><h2>$c1</h2> 
                  <h4 style='color:green; font-weight:bold;'> Total Amount - &#8358 $sum </h4>
                  </span> ";
                } else {
                  echo "<h2 style='color:green; font-weight:bold; text-align:center;'>&#8358 0 </h2>";
                }
                ?>





              </div>
            </div>
          </div>









          <!-- MONTHLY -->
          <div class="card card-plain">
            <div id="month" class="card-header card-header-primary d-flex justify-content-between">
              <h4 class="card-title">Monthly Report</h4>
              <div class="dropdown">
                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Select Month
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                  <a class="dropdown-item" href="#month" onclick="toggleVisibility('Menu1');">January</a>
                  <a class="dropdown-item" href="#month" onclick="toggleVisibility('Menu2');">February</a>
                  <a class="dropdown-item" href="#month" onclick="toggleVisibility('Menu3');">March</a>
                  <a class="dropdown-item" href="#month" onclick="toggleVisibility('Menu4');">April</a>
                  <a class="dropdown-item" href="#month" onclick="toggleVisibility('Menu5');">May</a>
                  <a class="dropdown-item" href="#month" onclick="toggleVisibility('Menu6');">June</a>
                  <a class="dropdown-item" href="#month" onclick="toggleVisibility('Menu7');">July</a>
                  <a class="dropdown-item" href="#month" onclick="toggleVisibility('Menu8');">August</a>
                  <a class="dropdown-item" href="#month" onclick="toggleVisibility('Menu9');">September</a>
                  <a class="dropdown-item" href="#month" onclick="toggleVisibility('Menu10');">October</a>
                  <a class="dropdown-item" href="#month" onclick="toggleVisibility('Menu11');">November</a>
                  <a class="dropdown-item" href="#month" onclick="toggleVisibility('Menu12');">December</a>
                </div>
              </div>
            </div>


            <!-- Jan -->
            <div id="Menu1">
              <div class="row">
                <div class="col-md-12">
                  <div class="card">
                    <div class="card-body">
                      <h3 style="font-weight: 900;" class="text-center text-primary m-1 bolder">JANUARY</h3>
                      <div class="table-responsive">
                        <table class="table table-striped">
                          <thead class="text-primary">
                            <th>Employee</th>
                            <th>Category</th>
                            <th>Services</th>
                            <th>Amount</th>
                            <th>Customer</th>
                            <th>Phone</th>
                            <th>Date & Time</th>
                          </thead>
                          <tbody>
                            <?php
                            $sales2 = mysqli_query($conn, "select * from sales WHERE month(datetime) = 1 and YEAR(datetime) = YEAR(NOW()) order by id desc");
                            while ($bdetails = mysqli_fetch_array($sales2)) {

                              $category2 = $bdetails['category'];
                              $services2 = $bdetails['services'];
                              $price2 = $bdetails['price'];
                              $staff2 = $bdetails['sales_rep'];
                              $customer2 = $bdetails['customer'];
                              $phone2 = $bdetails['phone'];
                              // $date = $adetails['date'];
                              $datetime2 = $bdetails['datetime'];
                            ?>
                              <?php
                              echo "<tr> 
                              <td>     $staff2         </td>   
                              <td>    $services2   </td>      
                               <td>    $category2  </td>           
                    <td style='font-weight:bold; color:green;'>$price2 </td>
                     <td>    $customer2  </td>
                      <td>   $phone2  </td>
                      <td>  $datetime2  </td>
                       </tr> ";  
                       ?>
                            <?php
                            }
                            ?>
                          </tbody>
                        </table>
                        <?php
                        $sumup = mysqli_query($conn, "SELECT SUM(price) AS totalsum FROM sales WHERE month(datetime) = 1 and YEAR(datetime) = YEAR(NOW())");
                        $amt = mysqli_fetch_row($sumup);
                        $sum = $amt[0];
                        $c1 = mysqli_num_rows($s);

                        if ($sumup) {
                          echo "  <span align='center'><h2>$c1</h2> 
  <h4 style='color:green; font-weight:bold;'> Total Amount - &#8358 $sum </h4>
  </span> ";
                        } else {
                          echo "<h2 style='color:green; font-weight:bold; text-align:center;'>&#8358 0 </h2>";
                        }
                        ?>
                      </div>

                    </div>
                  </div>
                </div>
              </div>
            </div>






              <!-- FEB -->

              <div id="Menu2" style="display: none;">
                <div class="row">
                  <div class="col-md-12">
                    <div class="card">
                      <div class="card-body">
                        <h3 style="font-weight: 900;" class="text-center text-primary m-1 bolder">FEBRUARY</h3>
                        <div class="table-responsive">
                          <table class="table table-striped">
                            <thead class="text-primary">
                              <th>Employee</th>                              
                              <th>Category</th>
                              <th>Services</th>
                              <th>Amount</th>
                              <th>Customer</th>
                              <th>Phone</th>
                              <th>Date & Time</th>
                            </thead>
                            <tbody>
                              <?php
                              $sales2 = mysqli_query($conn, "select * from sales WHERE month(datetime) = 2 and YEAR(datetime) = YEAR(NOW()) order by id desc");
                              while ($bdetails = mysqli_fetch_array($sales2)) {


                                $category2 = $bdetails['category'];
                                $services2 = $bdetails['services'];
                                $price2 = $bdetails['price'];
                                $staff2 = $bdetails['sales_rep'];
                                $customer2 = $bdetails['customer'];
                                $phone2 = $bdetails['phone'];
                                // $date = $adetails['date'];
                                $datetime2 = $bdetails['datetime'];
                              ?>


                                <?php
                                echo "<tr> 
                              <td>
                              $staff2
                            </td>   
                              <td>
                              $services2
                            </td>      
        <td>
        $category2
      </td>
           
      <td style='font-weight:bold; color:green;'>$price2 </td>
      <td>
      $customer2
    </td>
    <td>
    $phone2
  </td>
     
      <td>
       $datetime2
      </td>
                         
    </tr>
    ";  ?>
                              <?php
                              }
                              ?>
                            </tbody>
                          </table>

                          <?php
                          $sumup = mysqli_query($conn, "SELECT SUM(price) AS totalsum FROM sales WHERE month(datetime) = 2 and YEAR(datetime) = YEAR(NOW())");
                          $amt = mysqli_fetch_row($sumup);
                          $sum = $amt[0];
                          $c1 = mysqli_num_rows($s);

                          if ($sumup) {
                            echo "  <span align='center'><h2>$c1</h2> 
  <h4 style='color:green; font-weight:bold;'> Total Amount - &#8358 $sum </h4>
  </span> ";
                          } else {
                            echo "<h2 style='color:green; font-weight:bold; text-align:center;'>&#8358 0 </h2>";
                          }
                          ?>
                        </div>

                      </div>

                    </div>

                  </div>

                </div>
              </div>



                <!-- MARCH -->


                <div id="Menu3" style="display: none;">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="card">
                        <div class="card-body">
                          <h3 style="font-weight: 900;" class="text-center text-primary m-1 bolder">MARCH</h3>
                          <div class="table-responsive">
                            <table class="table table-striped">
                              <thead class="text-primary">
                                <th>Employee</th>
                                <th>Category</th>
                                <th>Services</th>
                                <th>Amount</th>
                                <th>Customer</th>
                                <th>Phone</th>
                                <th>Date & Time</th>
                              </thead>
                              <tbody>
                                <?php
                                $sales2 = mysqli_query($conn, "select * from sales WHERE month(datetime) = 3 and YEAR(datetime) = YEAR(NOW()) order by id desc");
                                while ($bdetails = mysqli_fetch_array($sales2)) {


                                  $category2 = $bdetails['category'];
                                  $services2 = $bdetails['services'];
                                  $price2 = $bdetails['price'];
                                  $staff2 = $bdetails['sales_rep'];
                                  $customer2 = $bdetails['customer'];
                                  $phone2 = $bdetails['phone'];
                                  // $date = $adetails['date'];
                                  $datetime2 = $bdetails['datetime'];
                                ?>


                                  <?php
                                  echo "<tr> 
                              <td>
                              $staff2
                            </td>   
                              <td>
                              $services2
                            </td>      
        <td>
        $category2
      </td>
           
      <td style='font-weight:bold; color:green;'>$price2 </td>
      <td>
      $customer2
    </td>
    <td>
    $phone2
  </td>
     
      <td>
       $datetime2
      </td>
                         
    </tr>
    ";  ?>
                                <?php
                                }
                                ?>
                              </tbody>
                            </table>

                            <?php
                            $sumup = mysqli_query($conn, "SELECT SUM(price) AS totalsum FROM sales WHERE month(datetime) = 3 and YEAR(datetime) = YEAR(NOW())");
                            $amt = mysqli_fetch_row($sumup);
                            $sum = $amt[0];
                            $c1 = mysqli_num_rows($s);

                            if ($sumup) {
                              echo "  <span align='center'><h2>$c1</h2> 
  <h4 style='color:green; font-weight:bold;'> Total Amount - &#8358 $sum </h4>
  </span> ";
                            } else {
                              echo "<h2 style='color:green; font-weight:bold; text-align:center;'>&#8358 0 </h2>";
                            }
                            ?>
                          </div>

                        </div>

                      </div>

                    </div>

                  </div>
                </div>





                  <!-- APRIL -->

                  <div id="Menu4" style="display: none;">
                    <div class="row">
                      <div class="col-md-12">
                        <div class="card">
                          <div class="card-body">
                            <h3 style="font-weight: 900;" class="text-center text-primary m-1 bolder">APRIL</h3>
                            <div class="table-responsive">
                              <table class="table table-striped">
                                <thead class="text-primary">
                                  <th>Employee</th>
                                  <th>Category</th>
                                  <th>Services</th>
                                  <th>Amount</th>
                                  <th>Customer</th>
                                  <th>Phone</th>
                                  <th>Date & Time</th>
                                </thead>
                                <tbody>
                                  <?php
                                  $sales2 = mysqli_query($conn, "select * from sales WHERE month(datetime) = 4 and YEAR(datetime) = YEAR(NOW()) order by id desc");
                                  while ($bdetails = mysqli_fetch_array($sales2)) {


                                    $category2 = $bdetails['category'];
                                    $services2 = $bdetails['services'];
                                    $price2 = $bdetails['price'];
                                    $staff2 = $bdetails['sales_rep'];
                                    $customer2 = $bdetails['customer'];
                                    $phone2 = $bdetails['phone'];
                                    // $date = $adetails['date'];
                                    $datetime2 = $bdetails['datetime'];
                                  ?>


                                    <?php
                                    echo "<tr> 
                              <td>
                              $staff2
                            </td>   
                              <td>
                              $services2
                            </td>      
        <td>
        $category2
      </td>
           
      <td style='font-weight:bold; color:green;'>$price2 </td>
      <td>
      $customer2
    </td>
    <td>
    $phone2
  </td>
     
      <td>
       $datetime2
      </td>
                         
    </tr>
    ";  ?>
                                  <?php
                                  }
                                  ?>
                                </tbody>
                              </table>

                              <?php
                              $sumup = mysqli_query($conn, "SELECT SUM(price) AS totalsum FROM sales WHERE month(datetime) = 4 and YEAR(datetime) = YEAR(NOW())");
                              $amt = mysqli_fetch_row($sumup);
                              $sum = $amt[0];
                              $c1 = mysqli_num_rows($s);

                              if ($sumup) {
                                echo "  <span align='center'><h2>$c1</h2> 
  <h4 style='color:green; font-weight:bold;'> Total Amount - &#8358 $sum </h4>
  </span> ";
                              } else {
                                echo "<h2 style='color:green; font-weight:bold; text-align:center;'>&#8358 0 </h2>";
                              }
                              ?>
                            </div>

                          </div>

                        </div>

                      </div>

                    </div>
                  </div>







                    <!-- MAY -->

                    <div id="Menu5" style="display: none;">
                      <div class="row">
                        <div class="col-md-12">
                          <div class="card">
                            <div class="card-body">
                              <h3 style="font-weight: 900;" class="text-center text-primary m-1 bolder">MAY</h3>
                              <div class="table-responsive">
                                <table class="table table-striped">
                                  <thead class="text-primary">
                                    <th>Employee</th>
                                    <th>Category</th>
                                    <th>Services</th>
                                    <th>Amount</th>
                                    <th>Customer</th>
                                    <th>Phone</th>
                                    <th>Date & Time</th>
                                  </thead>
                                  <tbody>
                                    <?php
                                    $sales2 = mysqli_query($conn, "select * from sales WHERE month(datetime) = 5 and YEAR(datetime) = YEAR(NOW()) order by id desc");
                                    while ($bdetails = mysqli_fetch_array($sales2)) {


                                      $category2 = $bdetails['category'];
                                      $services2 = $bdetails['services'];
                                      $price2 = $bdetails['price'];
                                      $staff2 = $bdetails['sales_rep'];
                                      $customer2 = $bdetails['customer'];
                                      $phone2 = $bdetails['phone'];
                                      // $date = $adetails['date'];
                                      $datetime2 = $bdetails['datetime'];
                                    ?>


                                      <?php
                                      echo "<tr> 
                              <td>
                              $staff2
                            </td>   
                              <td>
                              $services2
                            </td>      
        <td>
        $category2
      </td>
           
      <td style='font-weight:bold; color:green;'>$price2 </td>
      <td>
      $customer2
    </td>
    <td>
    $phone2
  </td>
     
      <td>
       $datetime2
      </td>
                         
    </tr>
    ";  ?>
                                    <?php
                                    }
                                    ?>
                                  </tbody>
                                </table>

                                <?php
                                $sumup = mysqli_query($conn, "SELECT SUM(price) AS totalsum FROM sales WHERE month(datetime) = 5 and YEAR(datetime) = YEAR(NOW())");
                                $amt = mysqli_fetch_row($sumup);
                                $sum = $amt[0];
                                $c1 = mysqli_num_rows($s);

                                if ($sumup) {
                                  echo "  <span align='center'><h2>$c1</h2> 
  <h4 style='color:green; font-weight:bold;'> Total Amount - &#8358 $sum </h4>
  </span> ";
                                } else {
                                  echo "<h2 style='color:green; font-weight:bold; text-align:center;'>&#8358 0 </h2>";
                                }
                                ?>
                              </div>

                            </div>

                          </div>

                        </div>

                      </div>
                    </div>












                      <!-- JUNE -->



                      <div id="Menu6" style="display: none;">
                        <div class="row">
                          <div class="col-md-12">
                            <div class="card">
                              <div class="card-body">
                                <h3 style="font-weight: 900;" class="text-center text-primary m-1 bolder">JUNE</h3>
                                <div class="table-responsive">
                                  <table class="table table-striped">
                                    <thead class="text-primary">
                                      <th>Employee</th>
                                      <th>Category</th>
                                      <th>Services</th>
                                      <th>Amount</th>
                                      <th>Customer</th>
                                      <th>Phone</th>
                                      <th>Date & Time</th>
                                    </thead>
                                    <tbody>
                                      <?php
                                      $sales2 = mysqli_query($conn, "select * from sales WHERE month(datetime) = 6 and YEAR(datetime) = YEAR(NOW()) order by id desc");
                                      while ($bdetails = mysqli_fetch_array($sales2)) {


                                        $category2 = $bdetails['category'];
                                        $services2 = $bdetails['services'];
                                        $price2 = $bdetails['price'];
                                        $staff2 = $bdetails['sales_rep'];
                                        $customer2 = $bdetails['customer'];
                                        $phone2 = $bdetails['phone'];
                                        // $date = $adetails['date'];
                                        $datetime2 = $bdetails['datetime'];
                                      ?>


                                        <?php
                                        echo "<tr> 
                              <td>
                              $staff2
                            </td>   
                              <td>
                              $services2
                            </td>      
        <td>
        $category2
      </td>
           
      <td style='font-weight:bold; color:green;'>$price2 </td>
      <td>
      $customer2
    </td>
    <td>
    $phone2
  </td>
     
      <td>
       $datetime2
      </td>
                         
    </tr>
    ";  ?>
                                      <?php
                                      }
                                      ?>
                                    </tbody>
                                  </table>

                                  <?php
                                  $sumup = mysqli_query($conn, "SELECT SUM(price) AS totalsum FROM sales WHERE month(datetime) = 6 and YEAR(datetime) = YEAR(NOW())");
                                  $amt = mysqli_fetch_row($sumup);
                                  $sum = $amt[0];
                                  $c1 = mysqli_num_rows($s);

                                  if ($sumup) {
                                    echo "  <span align='center'><h2>$c1</h2> 
  <h4 style='color:green; font-weight:bold;'> Total Amount - &#8358 $sum </h4>
  </span> ";
                                  } else {
                                    echo "<h2 style='color:green; font-weight:bold; text-align:center;'>&#8358 0 </h2>";
                                  }
                                  ?>
                                </div>

                              </div>

                            </div>

                          </div>

                        </div>
                      </div>











                        <!-- JULY -->


                        <div id="Menu7" style="display: none;">
                          <div class="row">
                            <div class="col-md-12">
                              <div class="card">
                                <div class="card-body">
                                  <h3 style="font-weight: 900;" class="text-center text-primary m-1 bolder">JULY</h3>
                                  <div class="table-responsive">
                                    <table class="table table-striped">
                                      <thead class="text-primary">
                                        <th>Employee</th>
                                        <th>Category</th>
                                        <th>Services</th>
                                        <th>Amount</th>
                                        <th>Customer</th>
                                        <th>Phone</th>
                                        <th>Date & Time</th>
                                      </thead>
                                      <tbody>
                                        <?php
                                        $sales2 = mysqli_query($conn, "select * from sales WHERE month(datetime) = 7 and YEAR(datetime) = YEAR(NOW()) order by id desc");
                                        while ($bdetails = mysqli_fetch_array($sales2)) {


                                          $category2 = $bdetails['category'];
                                          $services2 = $bdetails['services'];
                                          $price2 = $bdetails['price'];
                                          $staff2 = $bdetails['sales_rep'];
                                          $customer2 = $bdetails['customer'];
                                          $phone2 = $bdetails['phone'];
                                          // $date = $adetails['date'];
                                          $datetime2 = $bdetails['datetime'];
                                        ?>


                                          <?php
                                          echo "<tr> 
                              <td>
                              $staff2
                            </td>   
                              <td>
                              $services2
                            </td>      
        <td>
        $category2
      </td>
           
      <td style='font-weight:bold; color:green;'>$price2 </td>
      <td>
      $customer2
    </td>
    <td>
    $phone2
  </td>
     
      <td>
       $datetime2
      </td>
                         
    </tr>
    ";  ?>
                                        <?php
                                        }
                                        ?>
                                      </tbody>
                                    </table>

                                    <?php
                                    $sumup = mysqli_query($conn, "SELECT SUM(price) AS totalsum FROM sales WHERE month(datetime) = 7 and YEAR(datetime) = YEAR(NOW())");
                                    $amt = mysqli_fetch_row($sumup);
                                    $sum = $amt[0];
                                    $c1 = mysqli_num_rows($s);

                                    if ($sumup) {
                                      echo "  <span align='center'><h2>$c1</h2> 
  <h4 style='color:green; font-weight:bold;'> Total Amount - &#8358 $sum </h4>
  </span> ";
                                    } else {
                                      echo "<h2 style='color:green; font-weight:bold; text-align:center;'>&#8358 0 </h2>";
                                    }
                                    ?>
                                  </div>

                                </div>

                              </div>

                            </div>
                          </div>
                          </div>









                          <!-- AUG -->


                          <div id="Menu8" style="display: none;">
                            <div class="row">
                              <div class="col-md-12">
                                <div class="card">
                                  <div class="card-body">
                                    <h3 style="font-weight: 900;" class="text-center text-primary m-1 bolder">AUGUST</h3>
                                    <div class="table-responsive">
                                      <table class="table table-striped">
                                        <thead class="text-primary">
                                          <th>Employee</th>
                                          <th>Category</th>
                                          <th>Services</th>
                                          <th>Amount</th>
                                          <th>Customer</th>
                                          <th>Phone</th>
                                          <th>Date & Time</th>
                                        </thead>
                                        <tbody>
                                          <?php
                                          $sales2 = mysqli_query($conn, "select * from sales WHERE month(datetime) = 8 and YEAR(datetime) = YEAR(NOW()) order by id desc");
                                          while ($bdetails = mysqli_fetch_array($sales2)) {


                                            $category2 = $bdetails['category'];
                                            $services2 = $bdetails['services'];
                                            $price2 = $bdetails['price'];
                                            $staff2 = $bdetails['sales_rep'];
                                            $customer2 = $bdetails['customer'];
                                            $phone2 = $bdetails['phone'];
                                            // $date = $adetails['date'];
                                            $datetime2 = $bdetails['datetime'];
                                          ?>


                                            <?php
                                            echo "<tr> 
                              <td>
                              $staff2
                            </td>   
                              <td>
                              $services2
                            </td>      
        <td>
        $category2
      </td>
           
      <td style='font-weight:bold; color:green;'>$price2 </td>
      <td>
      $customer2
    </td>
    <td>
    $phone2
  </td>
     
      <td>
       $datetime2
      </td>
                         
    </tr>
    ";  ?>
                                          <?php
                                          }
                                          ?>
                                        </tbody>
                                      </table>

                                      <?php
                                      $sumup = mysqli_query($conn, "SELECT SUM(price) AS totalsum FROM sales WHERE month(datetime) = 8 and YEAR(datetime) = YEAR(NOW())");
                                      $amt = mysqli_fetch_row($sumup);
                                      $sum = $amt[0];
                                      $c1 = mysqli_num_rows($s);

                                      if ($sumup) {
                                        echo "  <span align='center'><h2>$c1</h2> 
  <h4 style='color:green; font-weight:bold;'> Total Amount - &#8358 $sum </h4>
  </span> ";
                                      } else {
                                        echo "<h2 style='color:green; font-weight:bold; text-align:center;'>&#8358 0 </h2>";
                                      }
                                      ?>
                                    </div>

                                  </div>

                                </div>
                              </div>
                            </div>
                            </div>










                            <!-- SEPT -->


                            <div id="Menu9" style="display: none;">
                              <div class="row">
                                <div class="col-md-12">
                                  <div class="card">
                                    <div class="card-body">
                                      <h3 style="font-weight: 900;" class="text-center text-primary m-1 bolder">SEPTEMBER</h3>
                                      <div class="table-responsive">
                                        <table class="table table-striped">
                                          <thead class="text-primary">
                                            <th>Employee</th>
                                            <th>Category</th>
                                            <th>Services</th>
                                            <th>Amount</th>
                                            <th>Customer</th>
                                            <th>Phone</th>
                                            <th>Date & Time</th>
                                          </thead>
                                          <tbody>
                                            <?php
                                            $sales2 = mysqli_query($conn, "select * from sales WHERE month(datetime) = 9 and YEAR(datetime) = YEAR(NOW()) order by id desc");
                                            while ($bdetails = mysqli_fetch_array($sales2)) {


                                              $category2 = $bdetails['category'];
                                              $services2 = $bdetails['services'];
                                              $price2 = $bdetails['price'];
                                              $staff2 = $bdetails['sales_rep'];
                                              $customer2 = $bdetails['customer'];
                                              $phone2 = $bdetails['phone'];
                                              // $date = $adetails['date'];
                                              $datetime2 = $bdetails['datetime'];
                                            ?>


                                              <?php
                                              echo "<tr> 
                              <td>
                              $staff2
                            </td>   
                              <td>
                              $services2
                            </td>      
        <td>
        $category2
      </td>
           
      <td style='font-weight:bold; color:green;'>$price2 </td>
      <td>
      $customer2
    </td>
    <td>
    $phone2
  </td>
     
      <td>
       $datetime2
      </td>
                         
    </tr>
    ";  ?>
                                            <?php
                                            }
                                            ?>
                                          </tbody>
                                        </table>

                                        <?php
                                        $sumup = mysqli_query($conn, "SELECT SUM(price) AS totalsum FROM sales WHERE month(datetime) = 9 and YEAR(datetime) = YEAR(NOW())");
                                        $amt = mysqli_fetch_row($sumup);
                                        $sum = $amt[0];
                                        $c1 = mysqli_num_rows($s);

                                        if ($sumup) {
                                          echo "  <span align='center'><h2>$c1</h2> 
  <h4 style='color:green; font-weight:bold;'> Total Amount - &#8358 $sum </h4>
  </span> ";
                                        } else {
                                          echo "<h2 style='color:green; font-weight:bold; text-align:center;'>&#8358 0 </h2>";
                                        }
                                        ?>
                                      </div>

                                    </div>

                                  </div>

                                </div>
                              </div>
                              </div>











                              <!-- OCT -->



                              <div id="Menu10" style="display: none;">
                                <div class="row">
                                  <div class="col-md-12">
                                    <div class="card">
                                      <div class="card-body">
                                        <h3 style="font-weight: 900;" class="text-center text-primary m-1 bolder">OCTOBER</h3>
                                        <div class="table-responsive">
                                          <table class="table table-striped">
                                            <thead class="text-primary">
                                              <th>Employee</th>
                                              <th>Category</th>
                                              <th>Services</th>
                                              <th>Amount</th>
                                              <th>Customer</th>
                                              <th>Phone</th>
                                              <th>Date & Time</th>
                                            </thead>
                                            <tbody>
                                              <?php
                                              $sales2 = mysqli_query($conn, "select * from sales WHERE month(datetime) = 10 and YEAR(datetime) = YEAR(NOW()) order by id desc");
                                              while ($bdetails = mysqli_fetch_array($sales2)) {


                                                $category2 = $bdetails['category'];
                                                $services2 = $bdetails['services'];
                                                $price2 = $bdetails['price'];
                                                $staff2 = $bdetails['sales_rep'];
                                                $customer2 = $bdetails['customer'];
                                                $phone2 = $bdetails['phone'];
                                                // $date = $adetails['date'];
                                                $datetime2 = $bdetails['datetime'];
                                              ?>


                                                <?php
                                                echo "<tr> 
                              <td>
                              $staff2
                            </td>   
                              <td>
                              $services2
                            </td>      
        <td>
        $category2
      </td>
           
      <td style='font-weight:bold; color:green;'>$price2 </td>
      <td>
      $customer2
    </td>
    <td>
    $phone2
  </td>
     
      <td>
       $datetime2
      </td>
                         
    </tr>
    ";  ?>
                                              <?php
                                              }
                                              ?>
                                            </tbody>
                                          </table>

                                          <?php
                                          $sumup = mysqli_query($conn, "SELECT SUM(price) AS totalsum FROM sales WHERE month(datetime) = 10 and YEAR(datetime) = YEAR(NOW())");
                                          $amt = mysqli_fetch_row($sumup);
                                          $sum = $amt[0];
                                          $c1 = mysqli_num_rows($s);

                                          if ($sumup) {
                                            echo "  <span align='center'><h2>$c1</h2> 
  <h4 style='color:green; font-weight:bold;'> Total Amount - &#8358 $sum </h4>
  </span> ";
                                          } else {
                                            echo "<h2 style='color:green; font-weight:bold; text-align:center;'>&#8358 0 </h2>";
                                          }
                                          ?>
                                        </div>

                                      </div>

                                    </div>

                                  </div>
                                </div>
                                </div>













                                <!-- NOV -->

                                <div id="Menu11" style="display: none;">
                                  <div class="row">
                                    <div class="col-md-12">
                                      <div class="card">
                                        <div class="card-body">
                                          <h3 style="font-weight: 900;" class="text-center text-primary m-1 bolder">NOVEMBER</h3>
                                          <div class="table-responsive">
                                            <table class="table table-striped">
                                              <thead class="text-primary">
                                                <th>Employee</th>
                                                <th>Category</th>
                                                <th>Services</th>
                                                <th>Amount</th>
                                                <th>Customer</th>
                                                <th>Phone</th>
                                                <th>Date & Time</th>
                                              </thead>
                                              <tbody>
                                                <?php
                                                $sales2 = mysqli_query($conn, "select * from sales WHERE month(datetime) = 11 and YEAR(datetime) = YEAR(NOW()) order by id desc");
                                                while ($bdetails = mysqli_fetch_array($sales2)) {


                                                  $category2 = $bdetails['category'];
                                                  $services2 = $bdetails['services'];
                                                  $price2 = $bdetails['price'];
                                                  $staff2 = $bdetails['sales_rep'];
                                                  $customer2 = $bdetails['customer'];
                                                  $phone2 = $bdetails['phone'];
                                                  // $date = $adetails['date'];
                                                  $datetime2 = $bdetails['datetime'];
                                                ?>


                                                  <?php
                                                  echo "<tr> 
                              <td>
                              $staff2
                            </td>   
                              <td>
                              $services2
                            </td>      
        <td>
        $category2
      </td>
           
      <td style='font-weight:bold; color:green;'>$price2 </td>
      <td>
      $customer2
    </td>
    <td>
    $phone2
  </td>
     
      <td>
       $datetime2
      </td>
                         
    </tr>
    ";  ?>
                                                <?php
                                                }
                                                ?>
                                              </tbody>
                                            </table>

                                            <?php
                                            $sumup = mysqli_query($conn, "SELECT SUM(price) AS totalsum FROM sales WHERE month(datetime) = 11 and YEAR(datetime) = YEAR(NOW())");
                                            $amt = mysqli_fetch_row($sumup);
                                            $sum = $amt[0];
                                            $c1 = mysqli_num_rows($s);

                                            if ($sumup) {
                                              echo "  <span align='center'><h2>$c1</h2> 
  <h4 style='color:green; font-weight:bold;'> Total Amount - &#8358 $sum </h4>
  </span> ";
                                            } else {
                                              echo "<h2 style='color:green; font-weight:bold; text-align:center;'>&#8358 0 </h2>";
                                            }
                                            ?>
                                          </div>

                                        </div>

                                      </div>

                                    </div>
                                  </div>
                                  </div>
















                                  <!-- DEC -->

                                  <div id="Menu12" style="display: none;">
                                    <div class="row">
                                      <div class="col-md-12">
                                        <div class="card">
                                          <div class="card-body">
                                            <h3 style="font-weight: 900;" class="text-center text-primary m-1 bolder">DECEMBER</h3>
                                            <div class="table-responsive">
                                              <table class="table table-striped">
                                                <thead class="text-primary">
                                                  <th>Employee</th>
                                                  <th>Category</th>
                                                  <th>Services</th>
                                                  <th>Amount</th>
                                                  <th>Customer</th>
                                                  <th>Phone</th>
                                                  <th>Date & Time</th>
                                                </thead>
                                                <tbody>
                                                  <?php
                                                  $sales2 = mysqli_query($conn, "select * from sales WHERE month(datetime) = 12 and YEAR(datetime) = YEAR(NOW()) order by id desc");
                                                  while ($bdetails = mysqli_fetch_array($sales2)) {


                                                    $category2 = $bdetails['category'];
                                                    $services2 = $bdetails['services'];
                                                    $price2 = $bdetails['price'];
                                                    $staff2 = $bdetails['sales_rep'];
                                                    $customer2 = $bdetails['customer'];
                                                    $phone2 = $bdetails['phone'];
                                                    // $date = $adetails['date'];
                                                    $datetime2 = $bdetails['datetime'];
                                                  ?>


                                                    <?php
                                                    echo "<tr> 
                              <td>
                              $staff2
                            </td>   
                              <td>
                              $services2
                            </td>      
        <td>
        $category2
      </td>
           
      <td style='font-weight:bold; color:green;'>$price2 </td>
      <td>
      $customer2
    </td>
    <td>
    $phone2
  </td>
     
      <td>
       $datetime2
      </td>
                         
    </tr>
    ";  ?>
                                                  <?php
                                                  }
                                                  ?>
                                                </tbody>
                                              </table>

                                              <?php
                                              $sumup = mysqli_query($conn, "SELECT SUM(price) AS totalsum FROM sales WHERE month(datetime) = 12 and YEAR(datetime) = YEAR(NOW())");
                                              $amt = mysqli_fetch_row($sumup);
                                              $sum = $amt[0];
                                              $c1 = mysqli_num_rows($s);

                                              if ($sumup) {
                                                echo "  <span align='center'><h2>$c1</h2> 
  <h4 style='color:green; font-weight:bold;'> Total Amount - &#8358 $sum </h4>
  </span> ";
                                              } else {
                                                echo "<h2 style='color:green; font-weight:bold; text-align:center;'>&#8358 0 </h2>";
                                              }
                                              ?>
                                            </div>

                                          </div>

                                        </div>

                                      </div>

                                    </div>


                                  </div>
                                </div>
                              </div>



                            </div>
                          </div>
                        </div>
                        <!-- JS Files -->
                        <script src="./table/table.js"></script>


                        <script>
                          var divs = ["Menu1", "Menu2", "Menu3", "Menu4", "Menu5", "Menu6", "Menu7", "Menu8", "Menu9", "Menu10", "Menu11", "Menu12"];
                          var visibleDivId = null;

                          function toggleVisibility(divId) {
                            if (visibleDivId === divId) {
                              //visibleDivId = null;
                            } else {
                              visibleDivId = divId;
                            }
                            hideNonVisibleDivs();
                          }

                          function hideNonVisibleDivs() {
                            var i, divId, div;
                            for (i = 0; i < divs.length; i++) {
                              divId = divs[i];
                              div = document.getElementById(divId);
                              if (visibleDivId === divId) {
                                div.style.display = "block";
                              } else {
                                div.style.display = "none";
                              }
                            }
                          }
                        </script>
</body>

</html>