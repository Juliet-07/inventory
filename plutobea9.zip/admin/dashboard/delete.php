<?php
session_start();
error_reporting(0);
include('../../register/connection.php');

$id=$_GET['id'];
$delete_sql = mysqli_query($conn,"DELETE FROM users WHERE id=$id");
if ($delete_sql) {
    // echo "<script>alert('User deleted');</script>";
   echo "<script>alert('User deleted');
   window.location.href = 'index.php'</script>";
   }else{
    echo "<script>alert('Cannot delete user');</script>";

   }
?>