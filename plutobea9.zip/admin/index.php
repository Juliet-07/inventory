<?php

include('../register/connection.php');

session_start();
// If form submitted, insert values into the database.
if (isset($_POST['username'])){
        // removes backslashes
	$admin = stripslashes($_REQUEST['username']);
        //escapes special characters in a string
	$admin = mysqli_real_escape_string($conn,$admin);
	$password = stripslashes($_REQUEST['password']);
	$password = mysqli_real_escape_string($conn,$password);
	//Checking is user existing in the database or not
        $query = "SELECT * FROM `admin` WHERE email='$admin'
and password='$password'";
	$result = mysqli_query($conn,$query) or die(mysqli_connect_error());
	$rows = mysqli_num_rows($result);
        if($rows==1){
	    $_SESSION['admin'] = $admin;
            // Redirect user to index.php
	    header("Location: dashboard");
         }
		 else{
			echo "<script>alert('Incorrect username and password')
		  window.location='index.php'
		</script>";  
			 }
    }else{
   
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
	<title>Spa Service Admin</title>
	<!-- Meta tag Keywords -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8" />
	<!-- CSS files -->
	<link rel="stylesheet" href="login/css/style.css" type="text/css" media="all" />
	<!-- Font-Awesome-Icons-CSS -->
	<link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
	<!-- web-fonts -->
	<link href="//fonts.googleapis.com/css?family=Tangerine:400,700" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i" rel="stylesheet">
</head>
	<!-- title -->
	<h1>
		<span>S</span>pa
		<span>S</span>ervices
		<span>A</span>dmin
	</h1>
	<!-- content -->
	<div class="sub-main-w3">
		<form class="login" action="" method="post">
			<p class="legend">Login Here</p>
			<div class="input">
				<input type="text" placeholder="Username" name="username" required />
				<span class="fa fa-envelope"></span>
			</div>
			<div class="input">
				<input type="password" placeholder="Password" name="password" required />
				<span class="fa fa-unlock"></span>
			</div>
			<!-- Should lead to admin dashboard -->
				<button type="submit" class="submit">
					<span class="fa fa-sign-in"></span>
				</button>
		</form>
	</div>
</body>
</html>

<?php } ?>