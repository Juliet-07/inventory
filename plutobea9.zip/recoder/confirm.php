<?php
session_start();
error_reporting(0);
include('../register/connection.php');

// $m=date("Y-m-d");

if (!isset($_SESSION["username"])) {
  header("Location: ../register/login.php");
}

$username = $_SESSION['username'];
// $_SESSION['category'] = $_POST['category'];
// $_SESSION['services'] = $_POST['services'];
///$_SESSION['price'] = $_POST['price'];


// $newCat = $category;
$Addons = "Add ons";
$body = "Body Sculpting & Skin Tightening";
$buttocks = "Buttocks & Breast Lifts";
$facials = "Facials";
$foot = "Foot & Hand Care";
$laser = "Laser Hair Removal";
$lashes = "Lashes";
$massage = "Massage";
$pmu = "PMU, Make-up & Eyebrow";
$skintt = "Skin Tightening Treatment";
$skint = "Skin Treatment";
$teeth = "Teeth Whitening";
$maxing = "Waxing (Hair Removal)";




// $category = $_SESSION['category'];
// $services = $_SESSION['services'];
//$price = $_SESSION['price'];

$price = $_GET['price'];
$services = $_GET['services'];
$category = $_GET['category'];



if (isset($_POST["button"])) {

  $Addons = "Add on";

  $_POST['price'] = $price;
  $_POST['services'] = $services;

  // $_SESSION['category'] = $_POST['category'];
  // $_SESSION['services'] = $_POST['services'];
  //$_SESSION['price'] = $_POST['price'];

  $price2 = $_POST['price'];
  $services2 = $_POST['services'];
  $category2 = $_POST['category'];


  $username = $_SESSION['username'];
  $customer = $_POST['customer'];
  $branch = $_POST['branch'];
  $phone = $_POST['phone'];
  $date = date('Y-m-d');

  // $category = $_SESSION['category'];
  // $services = $_SESSION['services'];
  //$price = $_SESSION['price'];


  if ($category == 1) {
    $sql = mysqli_query($conn, "insert into sales(category,services,price,date,sales_rep,customer, branch, phone) values
   ('$Addons','$services2','$price2','$date','$username','$customer', '$branch','$phone')");
  } 
  elseif ($category == 2) {
    $sql = mysqli_query($conn, "insert into sales(category,services,price,date,sales_rep,customer, branch, phone) values
     ('$body','$services2','$price2','$date','$username','$customer','$branch','$phone')");
  }
  elseif ($category == 3) {
    $sql = mysqli_query($conn, "insert into sales(category,services,price,date,sales_rep,customer,branch, phone) values
       ('$buttocks','$services2','$price2','$date','$username','$customer','$branch','$phone')");
  } 
  elseif ($category == 4) {
    $sql = mysqli_query($conn, "insert into sales(category,services,price,date,sales_rep,customer,branch, phone) values
         ('$facials','$services2','$price2','$date','$username','$customer','$branch','$phone')");
  }
  elseif ($category == 5) {
    $sql = mysqli_query($conn, "insert into sales(category,services,price,date,sales_rep,customer,branch, phone) values
           ('$foot','$services2','$price2','$date','$username','$customer','$branch','$phone')");
  } 
  elseif ($category == 6) {
    $sql = mysqli_query($conn, "insert into sales(category,services,price,date,sales_rep,customer,branch, phone) values
             ('$laser','$services2','$price2','$date','$username','$customer','$branch','$phone')");
  }
  elseif ($category == 7) {
    $sql = mysqli_query($conn, "insert into sales(category,services,price,date,sales_rep,customer,branch, phone) values
               ('$lashes','$services2','$price2','$date','$username','$customer','$branch','$phone')");
  } 
  elseif ($category == 8) {
    $sql = mysqli_query($conn, "insert into sales(category,services,price,date,sales_rep,customer,branch, phone) values
        ('$massage','$services2','$price2','$date','$username','$customer','$branch','$phone')");
  }
  elseif ($category == 9) {
    $sql = mysqli_query($conn, "insert into sales(category,services,price,date,sales_rep,customer,branch, phone) values
        ('$pmu','$services2','$price2','$date','$username','$customer','$branch','$phone')");
  } 
  elseif ($category == 10) {
    $sql = mysqli_query($conn, "insert into sales(category,services,price,date,sales_rep,customer,branch, phone) values
         ('$skintt','$services2','$price2','$date','$username','$customer','$branch','$phone')");
  }
  elseif ($category == 11) {
    $sql = mysqli_query($conn, "insert into sales(category,services,price,date,sales_rep,customer,branch, phone) values
          ('$skint','$services2','$price2','$date','$username','$customer','$branch','$phone')");
  } 
  elseif ($category == 12) {
    $sql = mysqli_query($conn, "insert into sales(category,services,price,date,sales_rep,customer,branch, phone) values
       ('$teeth','$services2','$price2','$date','$username','$customer','$branch','$phone')");
  }
   elseif ($category == 13) {
    $sql = mysqli_query($conn, "insert into sales(category,services,price,date,sales_rep,customer,branch, phone) values
    ('$maxing','$services2','$price2','$date','$username','$customer','$branch','$phone')");
  }

  if ($sql) {
    echo "<script>alert('Sales recorded successfully')</script>";
    header("Location: ../recoder/servicepage.php");
  }

  // elseif($body == $body){
  //   $sql = mysqli_query($conn, "insert into sales(category,services,price,date,sales_rep) values('$body','$services','$price','$date',$username)");
  //   echo "<script>alert('Sales recorded successfully')</script>";
  //   header("Location: ../recoder/servicepage.php");
  // }



  // $sql = mysqli_query($conn, "insert into sales(category,services,price,date) values('Add ons','$services','$price','$date')");


  else {
    echo "<script>alert('Sales record failed')</script>";
  }
}



?>


<!DOCTYPE html>
<html>

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <!-- CSS Files -->
  <link rel="stylesheet" href="recordstyles.css" />
  <link rel="stylesheet" href="../styling.css" />
  <!-- <link rel="stylesheet" href="../admin/styles.css" /> -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha512-dTfge/zgoMYpP7QbHy4gWMEGsbsdZeCXz7irItjcC3sPUFtf0kuFbDz/ixG7ArTxmDjLXDmezHubeNikyKGVyQ==" crossorigin="anonymous" />
  <script src="https://code.jquery.com/jquery-1.10.1.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>

<body>
  <!-- NAV BAR -->
  <nav class="navbar navbar-expand-lg navbar-light py-1">
    <div class="container px-4 py-0">
      <a class="navbar-brand text-white" href="#">PLUTOBEAUTY CAFE</a>
    </div>
  </nav>
  <div class="container">
    <div class="card">
      <table class="table">
        <form method="POST" action="">
          <thead>
            <tr class="bg-primary text-white">
              <th>BRANCH</th>
              <th>NAME</th>
              <th>PHONE NUMBER</th>
              <th>CATEGORY</th>
              <th>SERVICES</th>
              <th>PRICE</th>
            </tr>
          </thead>
          <tbody>
            <tr>
                 
              <td><input type="text" placeholder="Staff branch name" name="branch" required/></td>
              <td><input type="text" placeholder="Customer's name here" name="customer" required/></td>
              <td><input type="number" placeholder="Customer's number here" name="phone" required/></td>
              <td>
                <?php
                if ($category == 1) {
                  echo "$Addons";
                } elseif ($category == 2) {
                  echo "$body";
                }
                elseif ($category == 3) {
                  echo "$buttocks";
                }
                elseif ($category == 4) {
                  echo "$facials";
                }
                elseif ($category == 5) {
                  echo "$foot";
                }
                elseif ($category == 6) {
                  echo "$laser";
                }
                elseif ($category == 7) {
                  echo "$lashes";
                }
                elseif ($category == 8) {
                  echo "$massage";
                }
                elseif ($category == 9) {
                  echo "$pmu";
                }
                elseif ($category == 10) {
                  echo "$skintt";
                }
                elseif ($category == 11) {
                  echo "$skint";
                }
                elseif ($category == 12) {
                  echo "$teeth";
                }
                
                elseif ($category == 13) {
                  echo "$maxing";
                }



                ?></td>
              <?php
              echo "
                   
                    <td>
                   $services
                    </td>
                    <td style='font-weight:bold; color:green;'>$price </td>
                 
                  ";  ?>
            </tr>
            <tr>


              <td>
                <button class="dropbtn" name="button" type="submit">Submit</button>
              </td>
            </tr>
          </tbody>

        </form>
      </table>
    </div>
    <a href="index.php" style="font-size:20px;" class="py-4 my-4 text-white"> Go Back</a>

  </div>


  <script>
    if (window.history.replaceState) {
      window.history.replaceState(null, null, window.location.href);
    }
  </script>
</body>

</html>