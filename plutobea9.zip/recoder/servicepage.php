<?php
session_start();
error_reporting(0);
include('../register/connection.php');

// $m=date("Y-m-d");

if (!isset($_SESSION["username"])) {
  header("Location: ../register/login.php");
}

$username = $_SESSION['username'];

$sql = mysqli_query($conn, "select * from users where username='$username'");
while ($row = mysqli_fetch_array($sql)) {
  $user = $row['username'];
}

?>

<?php
if (isset($_POST["button"])) {
  $category = $_POST['category'];
  $services = $_POST['services'];
  $price = $_POST['price'];
  $date = date('Y-m-d');
  $sql = mysqli_query($conn, "insert into sales(category,services,price,date) values('$category','$services','$price','$date')");
  if ($sql) {
    echo "<script>alert('Sales recorded successfully')</script>";
  } else {
    echo "<script>alert('Sales record failed')</script>";

  }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Services</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <script src="https://code.jquery.com/jquery-1.10.1.min.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="recordstyles.css" />
  <link rel="stylesheet" href="../styling.css" />
</head>

<body>
  <!-- NAV BAR -->
  <nav class="navbar navbar-expand-lg navbar-light py-1">
    <a class="navbar-brand text-white">PLUTOBEAUTY CAFE</a>
  </nav>



  <div class="container mt-4">
  <div class="card">
              <div class="card-header border-0">
                <h3 class="card-title">RECORD </h3>                
              </div>

  <div class="card-body">
    <table class="table table-striped table-valign-middle">
      <thead>
        <tr class="bg-primary text-white">
          <th>CATEGORY</th>
          <th>SERVICES</th>
          <th>PRICE</th>
          <th>CUSTOMER</th>
          <th>PHONE</th>
          <th>DATE & TIME</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $sales = mysqli_query($conn, "select * from sales where sales_rep='$username' order by id desc");
        while ($adetails = mysqli_fetch_array($sales)) {


          $services = $adetails['services'];
          $category = $adetails['category'];
          $price = $adetails['price'];
        //  $staff = $adetails['sales_rep'];
         // $date = $adetails['date'];
          $customer = $adetails['customer'];
          $phone = $adetails['phone'];
          $datetime=$adetails['datetime'];
        ?>


          <?php
          echo "<tr>
                    <td>
                      $category
                    </td>
                    <td>
                     $services
                    </td>
                    <td style='font-weight:bold; color:green;'>$price </td>
                    <td>
                      $customer
                    </td>
                    <td>
                     $phone
                    </td>
                    <td>
                     $datetime
                    </td>
                                       
                  </tr>
                  ";  ?>
        <?php
        }
        ?>
        </tbody>
    </table>
  </div>
  </div>
  <a href="index.php" style="font-size:20px;" class="py-4 my-4 text-white"> Go Back</a>

  </div>






  <script>
    if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
    }
</script>
</body>

</html>