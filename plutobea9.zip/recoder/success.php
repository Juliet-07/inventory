<?php
    //Initializing the session
    session_start();
      
    $_SESSION['category'] = $_POST['category'];
    $_SESSION['services'] = $_POST['services'];
    $_SESSION['price'] = $_POST['price'];
    
      $date = date('Y-m-d');
    
    
      $insert_query = mysqli_query($conn,'insert into sales (
        category,
        services,
        price,
        customer,
        phone,
        sales_rep,
        date,
        ) values (
        ' . $_SESSION['services'] . ",
        " . $_SESSION['services'] . ",
        " . $_SESSION['price'] . ",
        " . $_POST['customer']. ",
        " . $_POST['phone']. ",
        " . $username. ",
        " . $date. "
        )");
    
        if ($insert_query) {
        echo "<script>alert('Sales recorded successfully')</script>";
        header("Location: ../recoder/servicepage.php");
        }
       else {
        echo "<script>alert('Sales record failed')</script>";
      }
 


    ?>