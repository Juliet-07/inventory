<?php
session_start();
error_reporting(0);
include('../register/connection.php');

// $m=date("Y-m-d");

if (!isset($_SESSION["username"])) {
  header("Location: ../register/login.php");
}

$username = $_SESSION['username'];
 $_SESSION['price'] = $price;
 $_SESSION['services'] = $services;






$sql = mysqli_query($conn, "select * from users where username='$username'");
while ($row = mysqli_fetch_array($sql)) {
  $user = $row['username'];
  
}


?>

<?php
if (isset($_POST["button"])) {
  $price = $_POST['price'];

 
    //$_SESSION['price'] = $price;
          // Redirect user to index.php
    header("Location: confirm.php");
      
 }


?>


<?php
if (isset($_POST["buttona"])) {
  $category = $_POST['category'];
  $services = $_POST['services'];
  $price = $_POST['price'];
  $date = date('Y-m-d');
  $sql = mysqli_query($conn, "insert into sales(category,services,price,date) values('Add ons','$services','$price','$date')");
  if ($sql) {
    echo "<script>alert('Sales recorded successfully')</script>";
    header("Location: ../recoder/servicepage.php");
  } else {
    echo "<script>alert('Sales record failed')</script>";
  }
}


?>



<!DOCTYPE html>
<html>

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <!-- CSS Files -->
  <link rel="stylesheet" href="recordstyles.css" />
  <link rel="stylesheet" href="../styling.css" />
  <!-- <link rel="stylesheet" href="../admin/styles.css" /> -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha512-dTfge/zgoMYpP7QbHy4gWMEGsbsdZeCXz7irItjcC3sPUFtf0kuFbDz/ixG7ArTxmDjLXDmezHubeNikyKGVyQ==" crossorigin="anonymous" />
  <script src="https://code.jquery.com/jquery-1.10.1.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>


  <script>
    function showCategory(str) {
      if (str == "") {
        document.getElementById("txtHint").innerHTML = "error";
        return;
      } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
            document.getElementById("txtHint").innerHTML = this.responseText;
          }
        };
        xmlhttp.open("GET", "index.php?q=" + str, true);
        xmlhttp.send();
      }
    }
  </script>
  <script type="text/javascript">
    $(document).ready(function() {

      $("#sel_category").change(function() {
        var cateid = $(this).val();

        $.ajax({
          url: 'getuser.php',
          type: 'post',
          data: {
            depart: cateid
          },
          dataType: 'json',
          success: function(response) {

            var len = response.length;

            $("#sel_services").empty();
            for (var i = 0; i < len; i++) {
              var id = response[i]['id'];
              var services = response[i]['services'];
             // var services =  id;


              $("#sel_services").append("<option value='" + services + "'>" + services + "</option>");

            }
          }
        });
      });

    });
  </script>
</head>

<body>
  <!-- NAV BAR -->
  <nav class="navbar navbar-expand-lg navbar-light py-1">
    <div class="container px-4 py-0">

      <div class="img">
        <a class="navbar-brand" href="../index.html">
          <img class="logo rounded-circle" src="../assets/logo.jpeg" alt="" />
        </a>
      </div>
      <a class="navbar-brand text-white bold" href="#">PLUTOBEAUTY CAFE</a>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ms-auto my-2 my-lg-0">
          <li class="nav-item">
            <a class="nav-link text-white" href="list.html">List</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="./servicepage.php">Records</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="logout.php">Logout</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>


  <div class="container">
    <div class="text-white pb-3">
      <h2>Welcome, <?php echo strtoupper($username); ?> </h2>
    </div>





    <div class="card">
      <div class="card-header border-0">
        <h5 class="card-title">RECORD SALES</h5>
      </div>
      <div class="card-body">
        <table class="table table-responsive">
          <thead>
            <tr class="bg-primary text-white">
              <th>CATEGORY</th>
              <th>SERVICES</th>
              <th>PRICE</th>
            </tr>
          </thead>

          <tbody>
            <form action="confirm.php" method="GET">
              <tr>

                <td>
                  <select id="sel_category" class="selectButton"  name="category" required>
                    <option value="0" >- Select -</option>
                    <?php
                    // Fetch Category
                    $sql_category = "SELECT * FROM category";
                    $category_data = mysqli_query($conn, $sql_category);
                    while ($row = mysqli_fetch_assoc($category_data)) {
                      $categoryid = $row['id'];
                      $category = $row['category'];
                     // $categoryid =  $category;
                      //$category =  $categoryid;

                        // $value = split(':, $category')[0];
                        // $text = split(':, $category')[1];

                      $text = explode(':' , $parts);

                      // Option
                      echo "<option value='" . $categoryid."' >" . $category . "</option>";
                    }
                    ?>
                  </select>
                </td>

                <td>
                  <select id="sel_services" class="selectButton" name="services" required>
                    <option value="0">- Select -</option>
                  </select>
                </td>

                <td>
                  <input type="number" name="price"  required/>
  
                  

                </td>
              </tr>

              <!-- Next -->



              <td>
                <div class="text-center">
                  <button class="dropbtn text-center" type="submit" >Submit</button>

                </div>
              </td>
            </form>

          </tbody>
        </table>
      </div>
    </div>






  </div>

  <script>
    if (window.history.replaceState) {
      window.history.replaceState(null, null, window.location.href);
    }
  </script>
  <script src="record.js"></script>
</body>

</html>