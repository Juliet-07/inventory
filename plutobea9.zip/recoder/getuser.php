<?php
include('../register/connection.php');

$categoryid = 0;

if(isset($_POST['depart'])){
   $categoryid = mysqli_real_escape_string($conn,$_POST['depart']);
}

$services_arr = array();

if($categoryid > 0){
    $sql = "SELECT id,services FROM products WHERE category=".$categoryid;

    $result = mysqli_query($conn,$sql);
    
    while( $row = mysqli_fetch_array($result) ){
        $servicesid = $row['id'];
        $services = $row['services'];
        $servicesid =  $services;

    
        $services_arr[] = array("id" => $servicesid, "services" => $services);
    }
}

// encoding array to json format
echo json_encode($services_arr);